#!/bin/bash
# Build on a Mac with Xcode 26+ and XcodeGen; no hidden signing or upload.
set -euo pipefail
cd "$(dirname "$0")"
stage="${LE_STAGE:-staged/v2}"
cd "$stage/ios"
mkdir -p build
xcodegen generate --spec project.yml
xcodebuild -project LokiStudy.xcodeproj -scheme LokiStudy -configuration Release \
  -destination 'generic/platform=iOS Simulator' -derivedDataPath build/ReleaseSimulator \
  CODE_SIGNING_ALLOWED=NO build > build/release-simulator.log 2>&1 || { tail -80 build/release-simulator.log; exit 1; }
xcodebuild -project LokiStudy.xcodeproj -scheme LokiStudy -configuration Release \
  -destination 'generic/platform=iOS' -archivePath build/LEWords.xcarchive \
  CODE_SIGNING_ALLOWED=NO archive > build/release-archive.log 2>&1 || { tail -80 build/release-archive.log; exit 1; }
python3 - <<'PY'
from pathlib import Path
import plistlib
app=Path('build/LEWords.xcarchive/Products/Applications/LokiStudy.app')
assert app.is_dir()
info=plistlib.loads((app/'Info.plist').read_bytes())
assert info['CFBundleIdentifier']=='dev.zcydrkv7yh.lewords'
assert info['CFBundleShortVersionString']=='1.0.0'
assert info['CFBundleVersion']=='2'
bundles=[app]+list((app/'PlugIns').glob('*.appex'))
assert len(bundles)==4
for bundle in bundles:
    manifest=plistlib.loads((bundle/'PrivacyInfo.xcprivacy').read_bytes())
    assert manifest['NSPrivacyTracking'] is False
    assert manifest['NSPrivacyCollectedDataTypes']==[]
    reasons=manifest['NSPrivacyAccessedAPITypes'][0]['NSPrivacyAccessedAPITypeReasons']
    assert '1C8F.1' in reasons
print('Release archive: main app and all three extensions contain the expected privacy manifests.')
PY
ditto -c -k --sequesterRsrc --keepParent build/LEWords.xcarchive build/LEWords-release-unsigned.xcarchive.zip
echo 'Unsigned Release archive validated. Distribution signing, complete assets and Apple validation are separate mandatory gates.'
