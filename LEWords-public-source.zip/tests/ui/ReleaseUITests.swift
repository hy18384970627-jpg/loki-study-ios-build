import XCTest

final class ReleaseUITests: XCTestCase {
    private let app = XCUIApplication()

    private func button(_ text: String) -> XCUIElement {
        app.buttons.matching(NSPredicate(format: "label CONTAINS %@", text)).firstMatch
    }

    private func myPage() {
        let my = app.webViews.buttons.matching(NSPredicate(format: "label CONTAINS %@", "我的")).firstMatch
        XCTAssertTrue(my.waitForExistence(timeout: 30), app.debugDescription)
        my.tap()
        let account = button("账户与同步")
        XCTAssertTrue(account.waitForExistence(timeout: 5) || button("切换或管理账号").waitForExistence(timeout: 10), app.debugDescription)
    }

    private func screenshot(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    func testStoreScreens() throws {
        continueAfterFailure = false
        app.launch()
        XCTAssertTrue(app.webViews.firstMatch.waitForExistence(timeout: 30))
        // These screens do not depend on the omitted private audio fixture.
        let plans = app.webViews.buttons.matching(NSPredicate(format: "label CONTAINS %@", "词书与计划")).firstMatch
        XCTAssertTrue(plans.waitForExistence(timeout: 30), app.debugDescription)
        plans.tap()
        XCTAssertTrue(app.webViews.staticTexts["换词书，共享同一份单词记忆。"].waitForExistence(timeout: 10))
        screenshot("store-study-plan")
        let progress = app.webViews.buttons.matching(NSPredicate(format: "label CONTAINS %@", "进度")).firstMatch
        XCTAssertTrue(progress.exists, app.debugDescription)
        progress.tap()
        XCTAssertTrue(app.webViews.staticTexts["学习进度"].waitForExistence(timeout: 10))
        screenshot("store-learning-progress")
        myPage()
        if button("账户与同步").exists {
            button("账户与同步").tap()
            XCTAssertTrue(app.navigationBars["账户与同步"].waitForExistence(timeout: 15))
            screenshot("store-apple-account")
        } else {
            button("切换或管理账号").tap()
            XCTAssertTrue(app.navigationBars["学习账号"].waitForExistence(timeout: 15))
            screenshot("store-local-profiles")
        }
    }

    func testOfflineProfileLifecycle() throws {
        continueAfterFailure = false
        app.launch()
        XCTAssertTrue(app.webViews.firstMatch.waitForExistence(timeout: 30))
        myPage()
        XCTAssertTrue(app.webViews.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "我的账号")).firstMatch.waitForExistence(timeout: 15), app.debugDescription)
        screenshot("native-default-profile")
        button("切换或管理账号").tap()
        XCTAssertTrue(app.navigationBars["学习账号"].waitForExistence(timeout: 15), app.debugDescription)
        screenshot("native-profile-manager")
        let name = app.textFields.matching(NSPredicate(format: "placeholderValue == %@", "账号名称")).firstMatch
        XCTAssertTrue(name.exists, app.debugDescription)
        name.tap(); name.typeText("Release QA")
        button("创建并切换").tap()
        myPage()
        XCTAssertTrue(app.webViews.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "Release QA")).firstMatch.waitForExistence(timeout: 15), app.debugDescription)
        screenshot("native-second-profile")
        button("切换或管理账号").tap()
        XCTAssertTrue(app.navigationBars["学习账号"].waitForExistence(timeout: 15))
        button("我的账号").tap()
        myPage()
        XCTAssertTrue(app.webViews.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "我的账号")).firstMatch.waitForExistence(timeout: 15))
        button("隐私政策").tap()
        XCTAssertTrue(app.webViews.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "不上传至开发者服务器")).firstMatch.waitForExistence(timeout: 15))
        screenshot("native-privacy-policy")
        button("返回我的").tap()
        button("切换或管理账号").tap()
        XCTAssertTrue(app.navigationBars["学习账号"].waitForExistence(timeout: 15))
        button("Release QA").tap()
        myPage()
        button("切换或管理账号").tap()
        XCTAssertTrue(app.navigationBars["学习账号"].waitForExistence(timeout: 15))
        let remove = button("删除当前账号及学习记录")
        if !remove.isHittable { app.swipeUp() }
        remove.tap()
        XCTAssertTrue(app.alerts["删除当前账号？"].waitForExistence(timeout: 10))
        app.alerts["删除当前账号？"].buttons["删除"].tap()
        myPage()
        XCTAssertTrue(app.webViews.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "我的账号")).firstMatch.waitForExistence(timeout: 15))
        screenshot("native-surviving-profile")
    }
}
