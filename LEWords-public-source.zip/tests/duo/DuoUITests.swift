import XCTest
final class DuoUITests: XCTestCase {
    func testDuoViewsAndRotation() throws {
        continueAfterFailure=false
        let app=XCUIApplication();app.launch()
        XCTAssertTrue(app.webViews.firstMatch.waitForExistence(timeout:45))
        let plan=app.webViews.buttons.matching(NSPredicate(format:"label CONTAINS %@","词书与计划")).firstMatch
        XCTAssertTrue(plan.waitForExistence(timeout:30),app.debugDescription)
        plan.tap()
        XCTAssertTrue(app.webViews.staticTexts["换词书，共享同一份单词记忆。"].waitForExistence(timeout:15))
        capture("duo-plan-portrait",app)
        XCUIDevice.shared.orientation = .landscapeLeft
        XCTAssertTrue(plan.waitForExistence(timeout:10))
        capture("duo-plan-landscape",app)
        let stats=app.webViews.buttons.matching(NSPredicate(format:"label CONTAINS %@","进度")).firstMatch
        stats.tap()
        XCTAssertTrue(app.webViews.staticTexts["学习进度"].waitForExistence(timeout:15))
        capture("duo-progress-landscape",app)
        XCUIDevice.shared.orientation = .portrait
        XCTAssertTrue(app.webViews.staticTexts["学习进度"].waitForExistence(timeout:10))
        capture("duo-progress-portrait",app)
    }
    private func capture(_ name:String,_ app:XCUIApplication) {
        let item=XCTAttachment(screenshot:app.screenshot());item.name=name;item.lifetime = .keepAlways;add(item)
    }
}
