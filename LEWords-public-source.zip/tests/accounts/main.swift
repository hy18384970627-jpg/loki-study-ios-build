import Foundation

enum StudyError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(text) = self { return text }; return nil }
}

func check(_ value: Bool, _ message: String = "Account invariant failed") { precondition(value, message) }

let root = FileManager.default.temporaryDirectory.appendingPathComponent("LEAccountsTest-" + UUID().uuidString)
defer { try? FileManager.default.removeItem(at: root) }
let store = StudyAccountStore(root: root)
let original = try store.active()
let originalFolder = try store.activeFolder()
let originalData = Data("private-progress-A".utf8)
try originalData.write(to: originalFolder.appendingPathComponent("events.json"))
let second = try store.create("第二位用户")
check(second.id != original.id)
let secondFolder = try store.activeFolder()
check(!FileManager.default.fileExists(atPath: secondFolder.appendingPathComponent("events.json").path))
var rejected = false
do { try store.requireActive(original.id) } catch { rejected = true }
check(rejected, "Stale profile writes must be rejected")
try store.requireActive(second.id)
rejected = false
do { _ = try store.create(" 第二位用户 ") } catch { rejected = true }
check(rejected, "Duplicate account names must not merge profiles")
rejected = false
do { try store.select("../../outside") } catch { rejected = true }
check(rejected, "Arbitrary paths cannot be selected as profiles")
try store.select(original.id)
check(try Data(contentsOf: store.activeFolder().appendingPathComponent("events.json")) == originalData)
try store.renameActive("第一个账号")
check(try store.active().id == original.id)
check(try store.active().name == "第一个账号")
try store.select(second.id)
try store.deleteActive()
check(!FileManager.default.fileExists(atPath: secondFolder.path))
check(try store.active().id == original.id)
check(try Data(contentsOf: originalFolder.appendingPathComponent("events.json")) == originalData)
try store.deleteActive()
let replacement = try store.active()
check(replacement.id != original.id)
check(!FileManager.default.fileExists(atPath: originalFolder.path))
check(try store.snapshot().accounts.count == 1)
print("Native accounts: isolated folders, switching, stale-write rejection, naming, deletion and fresh default passed.")
