import Foundation

enum StudyError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(text) = self { return text }; return nil }
}

func check(_ value: Bool, _ message: String = "Account invariant failed") { precondition(value, message) }

let root = FileManager.default.temporaryDirectory.appendingPathComponent("LEAccountsTest-" + UUID().uuidString)
defer { try? FileManager.default.removeItem(at: root) }
let store = StudyAccountStore(root: root)
let original = try store.active()
let originalFolder = try store.activeFolder()
let originalData = Data("private-progress-A".utf8)
try originalData.write(to: originalFolder.appendingPathComponent("events.json"))
let second = try store.create("第二位用户")
check(second.id != original.id)
let secondFolder = try store.activeFolder()
check(!FileManager.default.fileExists(atPath: secondFolder.appendingPathComponent("events.json").path))
var rejected = false
do { try store.requireActive(original.id) } catch { rejected = true }
check(rejected, "Stale profile writes must be rejected")
try store.requireActive(second.id)
rejected = false
do { _ = try store.create(" 第二位用户 ") } catch { rejected = true }
check(rejected, "Duplicate account names must not merge profiles")
rejected = false
do { try store.select("../../outside") } catch { rejected = true }
check(rejected, "Arbitrary paths cannot be selected as profiles")
try store.select(original.id)
check(try Data(contentsOf: store.activeFolder().appendingPathComponent("events.json")) == originalData)
try store.renameActive("第一个账号")
check(try store.active().id == original.id)
check(try store.active().name == "第一个账号")
try store.select(second.id)
try store.deleteActive()
check(!FileManager.default.fileExists(atPath: secondFolder.path))
check(try store.active().id == original.id)
check(try Data(contentsOf: originalFolder.appendingPathComponent("events.json")) == originalData)
try store.deleteActive()
let replacement = try store.active()
check(replacement.id != original.id)
check(!FileManager.default.fileExists(atPath: originalFolder.path))
check(try store.snapshot().accounts.count == 1)
print("Native accounts: isolated folders, switching, stale-write rejection, naming, deletion and fresh default passed.")

let appleA = String(repeating: "a", count: 64)
let appleB = String(repeating: "b", count: 64)
let guestBeforeLogin = try store.activateGuest()
let ownerA = try store.activateApple(ownerHash: appleA)
try store.requireOwner(appleA)
rejected = false
do { try store.requireOwner(appleB) } catch { rejected = true }
check(rejected, "A different authenticated owner must not access active records")
rejected = false
do { try store.requireOwner(nil) } catch { rejected = true }
check(rejected, "Guest access must not read an Apple-owned profile")
let ownerB = try store.activateApple(ownerHash: appleB)
check(ownerA.id != ownerB.id)
check(try store.activateApple(ownerHash: appleA).id == ownerA.id)
check(try store.activateGuest().id == guestBeforeLogin.id)
let otherRoot = root.appendingPathComponent("another-device")
let otherDevice = StudyAccountStore(root: otherRoot)
check(try otherDevice.activateApple(ownerHash: appleA).id == ownerA.id, "Same identity must have stable cross-device profile ID")
_ = try store.activateApple(ownerHash: appleA)
try store.deleteActive()
check(try store.active().appleOwnerHash == nil, "Deleting an authenticated profile must return to a guest, never another owner")
check(try store.snapshot().accounts.contains(where: { $0.id == ownerB.id }), "Deleting one owner must preserve the other owner")
print("Native Apple ownership: stable identities, guest separation, wrong-owner rejection and safe deletion passed.")
