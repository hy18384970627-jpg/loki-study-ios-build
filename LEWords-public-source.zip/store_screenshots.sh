#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
script_root="$PWD"
cd "${LE_STAGE:-staged/v2}/ios"
mkdir -p Tests/UI build
cp "$script_root/tests/ui/ReleaseUITests.swift" Tests/UI/
python3 - <<'PY'
from pathlib import Path
p=Path('project.yml');s=p.read_text()
target='''  ReleaseUITests:
    type: bundle.ui-testing
    platform: iOS
    sources: [Tests/UI]
    settings:
      base:
        PRODUCT_BUNDLE_IDENTIFIER: dev.zcydrkv7yh.lewords.release-uitests
        GENERATE_INFOPLIST_FILE: YES
        TEST_TARGET_NAME: LokiStudy
    dependencies:
      - target: LokiStudy
'''
s=s.replace('schemes:\n',target+'schemes:\n')
s+='''    test:
      config: Debug
      targets: [ReleaseUITests]
'''
p.write_text(s)
PY
xcodegen generate --spec project.yml
python3 - <<'PY' > build/capture-devices.txt
import json,subprocess
d=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','available','-j']))
devices=[v for k,items in d['devices'].items() if 'iOS-26' in k for v in items]
phone=next(v for v in devices if v['name'].startswith('iPhone') and 'Pro Max' not in v['name'])
pad=next(v for v in devices if v['name'].startswith('iPad') and '13-inch' in v['name'])
for label,v in [('phone',phone),('pad',pad)]:print(label+' '+v['udid'])
PY
while read -r label sim_id; do
  xcrun simctl boot "$sim_id" || true
  xcrun simctl bootstatus "$sim_id" -b
  xcrun simctl status_bar "$sim_id" override --time '9:41' --batteryState charged --batteryLevel 100
  xcodebuild -project LokiStudy.xcodeproj -scheme LokiStudy -configuration Debug \
    -destination "platform=iOS Simulator,id=$sim_id" -derivedDataPath build/StoreDerived \
    -resultBundlePath "build/Store-$label.xcresult" CODE_SIGNING_ALLOWED=NO \
    -only-testing:ReleaseUITests/ReleaseUITests/testStoreScreens \
    -parallel-testing-enabled NO test > "build/store-$label.log" 2>&1 || { tail -100 "build/store-$label.log"; exit 1; }
  mkdir -p "build/native-screenshots/$label"
  xcrun xcresulttool export attachments --path "build/Store-$label.xcresult" --output-path "build/native-screenshots/$label"
  xcrun simctl shutdown "$sim_id"
done < build/capture-devices.txt
ditto -c -k --keepParent build/native-screenshots build/store-screenshots.zip
echo 'Captured actual native plan, progress and local-profile screens on iPhone and iPad. No private audio or histories uploaded.'
