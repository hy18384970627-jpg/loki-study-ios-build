#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
test -f ../web/index.html
test -f ../web/app.js
test -f ../web/vendor/fsrs.js
command -v xcodegen >/dev/null || { echo 'XcodeGen required'; exit 1; }
xcodegen generate --spec project.yml
mode="${1:-all}"
if [[ "$mode" == all || "$mode" == simulator ]]; then
  xcodebuild -project LokiStudy.xcodeproj -scheme LokiStudy -configuration Debug -sdk iphonesimulator \
    -destination 'generic/platform=iOS Simulator' -derivedDataPath build/Simulator \
    CODE_SIGNING_ALLOWED=NO build > build/simulator.log 2>&1 || { tail -100 build/simulator.log; exit 1; }
  ditto -c -k --sequesterRsrc --keepParent build/Simulator/Build/Products/Debug-iphonesimulator/LokiStudy.app build/LokiStudy-simulator.zip
fi
if [[ "$mode" == all || "$mode" == device ]]; then
  xcodebuild -project LokiStudy.xcodeproj -scheme LokiStudy -configuration Debug -sdk iphoneos \
    -destination 'generic/platform=iOS' -derivedDataPath build/Device \
    CODE_SIGNING_ALLOWED=NO build > build/device.log 2>&1 || { tail -100 build/device.log; exit 1; }
  ditto -c -k --sequesterRsrc --keepParent build/Device/Build/Products/Debug-iphoneos/LokiStudy.app build/LokiStudy-device-unsigned.zip
fi
echo 'Unsigned build complete; independent Apple development profiles and phone acceptance still required.'
