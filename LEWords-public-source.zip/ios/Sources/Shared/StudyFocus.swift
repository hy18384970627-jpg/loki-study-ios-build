import Foundation
import FamilyControls
import ManagedSettings
import DeviceActivity

enum StudyFocus {
    static let daily = ManagedSettingsStore(named: .init("LokiStudyDaily"))
    static let exam = ManagedSettingsStore(named: .init("LokiStudyExam"))
    static let dailyActivity = DeviceActivityName("LokiStudyDaily")
    static let examActivity = DeviceActivityName("LokiStudyExam")
    static var defaults: UserDefaults? {
        guard let group = Bundle.main.object(forInfoDictionaryKey: "LokiStudyAppGroup") as? String else { return nil }
        return UserDefaults(suiteName: group)
    }
    static var calendar: Calendar {
        var value = Calendar(identifier: .gregorian)
        value.timeZone = TimeZone(identifier: "Asia/Shanghai")!
        return value
    }
    static func day(_ now: Date = Date()) -> String {
        let c = calendar.dateComponents([.year, .month, .day], from: now)
        return String(format: "%04d-%02d-%02d", c.year!, c.month!, c.day!)
    }
    static func selection(_ key: String) -> FamilyActivitySelection {
        guard let data = defaults?.data(forKey: key), let value = try? JSONDecoder().decode(FamilyActivitySelection.self, from: data) else { return .init() }
        return value
    }
    static func setSelection(_ value: FamilyActivitySelection, key: String) {
        defaults?.set(try? JSONEncoder().encode(value), forKey: key)
    }
    static func hasSelection(_ value: FamilyActivitySelection) -> Bool {
        !value.applicationTokens.isEmpty || !value.categoryTokens.isEmpty || !value.webDomainTokens.isEmpty
    }
    static func shield(_ store: ManagedSettingsStore, _ value: FamilyActivitySelection) {
        store.shield.applications = value.applicationTokens.isEmpty ? nil : value.applicationTokens
        store.shield.applicationCategories = value.categoryTokens.isEmpty ? nil : .specific(value.categoryTokens)
        store.shield.webDomains = value.webDomainTokens.isEmpty ? nil : value.webDomainTokens
    }
    static func refresh() {
        guard let state = defaults else { return }
        if let expires = state.object(forKey: "examExpires") as? Date, expires <= Date() { endExam() }
        let complete = state.string(forKey: "completedDay") == day()
        let exempt = state.string(forKey: "emergencyDay") == day()
        if state.bool(forKey: "dailyEnabled") && !complete && !exempt {
            shield(daily, selection("socialSelection"))
        } else { daily.clearAllSettings() }
    }
    static func saveSummary(_ summary: [String: Any]) {
        guard let date = summary["day"] as? String, date == day(),
              let total = summary["total"] as? Int, let remaining = summary["remaining"] as? Int,
              total >= 0, remaining >= 0, remaining <= total else { return }
        defaults?.set(remaining, forKey: "remaining")
        defaults?.set(date, forKey: "summaryDay")
        if summary["complete"] as? Bool == true && total > 0 && remaining == 0 {
            defaults?.set(date, forKey: "completedDay")
        } else { defaults?.removeObject(forKey: "completedDay") }
        refresh()
    }
    static func endExam() {
        exam.clearAllSettings()
        defaults?.removeObject(forKey: "examExpires")
    }
    static func emergencyRelease() {
        defaults?.set(day(), forKey: "emergencyDay")
        daily.clearAllSettings(); endExam()
        DeviceActivityCenter().stopMonitoring([examActivity])
    }
    static var shieldMessage: String {
        if let expires = defaults?.object(forKey: "examExpires") as? Date, expires > Date() {
            return "听力还没结束。回到题目上，把这一套做完。需要应急解除时，打开 LE 单词的专注设置。"
        }
        let remaining = defaults?.integer(forKey: "remaining") ?? 0
        let detail = defaults?.string(forKey: "summaryDay") == day() && remaining > 0 ? "还剩 \(remaining) 个词。" : ""
        return "今天的单词还没背完，你倒先找到这里来了。\(detail)回到 LE 单词，完成今天的任务。需要应急解除时，打开专注设置。"
    }
}
