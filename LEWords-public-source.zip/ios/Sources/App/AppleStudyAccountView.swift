import SwiftUI
import AuthenticationServices

struct AppleStudyAccountView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var identity = StudyIdentity.shared
    @State private var requestState = ""
    @State private var busy = false
    @State private var message = ""
    @State private var confirmLogout = false
    @State private var confirmDeletion = false
    @State private var confirmImport = false
    @State private var deleting = false

    var body: some View {
        NavigationStack {
            Form {
                Section("当前账户") {
                    Label(identity.signedIn ? "已使用 Apple 登录" : "游客", systemImage: identity.signedIn ? "person.crop.circle.badge.checkmark" : "person.crop.circle")
                    Text(identity.status).foregroundStyle(.secondary)
                    if let date = identity.lastSynced { LabeledContent("上次同步", value: date.formatted(date: .abbreviated, time: .shortened)) }
                }
                if !identity.signedIn || deleting {
                    Section(deleting ? "验证 Apple 账户以注销" : "登录并恢复学习进度") {
                        Text(deleting ? "确认后会删除本账户的云端学习记录和此设备缓存。游客档案及其他人的账户不会被删除。" : "使用当前 iCloud 登录的 Apple 账户。在其他 iPhone 或 iPad 登录同一账户后，可恢复已同步的进度，无需另设手机号或密码。")
                        SignInWithAppleButton(.continue) { request in
                            requestState = UUID().uuidString
                            request.state = requestState
                            request.requestedScopes = []
                        } onCompletion: { result in
                            Task { @MainActor in
                                busy = true; message = ""
                                defer { busy = false }
                                do {
                                    let authorization = try result.get()
                                    guard let credential = authorization.credential as? ASAuthorizationAppleIDCredential,
                                          credential.state == requestState else { throw StudyError.message("Apple 授权请求不匹配，请重试。") }
                                    if deleting { try await identity.deleteAccount(credential: credential); deleting = false }
                                    else { try await identity.authorize(credential) }
                                } catch {
                                    if (error as? ASAuthorizationError)?.code != .canceled { message = error.localizedDescription }
                                }
                            }
                        }
                        .signInWithAppleButtonStyle(.white)
                        .frame(height: 48)
                        .disabled(busy || identity.deletionPending)
                        if deleting { Button("取消注销") { deleting = false }.disabled(busy) }
                    }
                }
                if identity.signedIn && !deleting {
                    Section("学习进度") {
                        Button(identity.syncing ? "正在同步…" : "立即同步") { Task { await identity.sync() } }
                            .disabled(busy || identity.syncing || identity.deletionPending)
                        if identity.canImportGuest {
                            Button("合并此设备的游客进度") { confirmImport = true }.disabled(busy || identity.deletionPending)
                        }
                        Text("离线时先保存在此设备，联网并打开 App 后自动同步。内置录音和你导入的音频保留在设备中。系统专注权限需在每台设备分别设置。")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Section("账户管理") {
                        Button("退出登录") { confirmLogout = true }.disabled(busy || identity.deletionPending)
                        Button("注销账户", role: .destructive) { confirmDeletion = true }.disabled(busy || identity.deletionPending)
                        if identity.deletionPending { Button("继续完成注销") { Task { await identity.refreshAuthorization() } } }
                    }
                }
                if !identity.signedIn {
                    Section {
                        Text("游客进度只保存在这台设备。登录时不会自动上传旧档案；你可在登录后选择是否合并当前游客进度。")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                if busy { ProgressView("正在处理 Apple 账户…") }
                if !message.isEmpty { Text(message).foregroundStyle(.red) }
            }
            .navigationTitle("账户与同步")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("完成") { dismiss() }.disabled(busy) } }
            .interactiveDismissDisabled(busy)
            .alert("退出当前账户？", isPresented: $confirmLogout) {
                Button("取消", role: .cancel) {}
                Button("退出登录") { perform { try identity.logout() } }
            } message: { Text("云端进度会保留。尚未同步的记录继续留在此设备，只有下次登录原账户后才会继续同步。") }
            .alert("合并游客进度？", isPresented: $confirmImport) {
                Button("取消", role: .cancel) {}
                Button("合并到当前 Apple 账户") { perform { try identity.importGuest() } }
            } message: { Text("当前游客档案的学习记录、计划和生词会合并到已登录账户并同步至 iCloud。不会合并旧版的其他本机档案。") }
            .alert("注销账户及学习记录？", isPresented: $confirmDeletion) {
                Button("取消", role: .cancel) {}
                Button("继续验证并注销", role: .destructive) { deleting = true }
            } message: { Text("此操作会永久删除本账户的云端学习记录和此设备缓存，随后撤销 Apple 登录授权。需要联网，并再次使用 Apple 验证身份。") }
        }
    }
    private func perform(_ action: () throws -> Void) {
        do { try action(); message = "" } catch { message = error.localizedDescription }
    }
}
