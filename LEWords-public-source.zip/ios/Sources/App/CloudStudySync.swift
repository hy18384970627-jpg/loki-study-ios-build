import Foundation
import CloudKit
import CryptoKit

struct StudyCloudBinding: Codable, Equatable {
    let appleOwnerHash: String
    let cloudOwner: String
    let epoch: String
}

struct StudyCloudPull {
    let events: [[String: Any]]
    let token: CKServerChangeToken?
    let knownIDs: Set<String>
}

enum StudyCloudIdentityError: LocalizedError, Equatable {
    case ownerChanged, accountDeleted, epochChanged
    var errorDescription: String? {
        switch self {
        case .ownerChanged: return "iCloud 账户已变化，请重新登录。原账户缓存仍保留。"
        case .accountDeleted: return "云端账户已注销。旧记录不会重新上传，请重新登录。"
        case .epochChanged: return "云端账户已重建，旧会话已退出，请重新登录。"
        }
    }
}

private final class CloudChanges: @unchecked Sendable {
    private let lock = NSLock()
    var records: [CKRecord] = []
    var token: CKServerChangeToken?
    var error: Error?
    func update(_ body: (CloudChanges) -> Void) { lock.lock(); defer { lock.unlock() }; body(self) }
}

actor CloudStudySync {
    static let shared = CloudStudySync()
    private let container = CKContainer(identifier: "iCloud.dev.zcydrkv7yh.lewords")
    private var database: CKDatabase { container.privateCloudDatabase }
    static func hash(_ value: String) -> String { SHA256.hash(data: Data(value.utf8)).map { String(format: "%02x", $0) }.joined() }
    private func zone(_ owner: String) -> CKRecordZone.ID { CKRecordZone.ID(zoneName: "LEStudy-" + String(owner.prefix(32)), ownerName: CKCurrentUserDefaultName) }
    private func metaID(_ owner: String) -> CKRecord.ID { CKRecord.ID(recordName: "account", zoneID: zone(owner)) }

    private func cloudOwner() async throws -> String {
        let state: CKAccountStatus
        do { state = try await container.accountStatus() }
        catch { throw StudyConnectionFailure(stage: "检查 iCloud 账户状态", underlying: error) }
        guard state == .available else { throw StudyError.message("请先在系统设置中登录 iCloud 并开启 LE 单词的 iCloud 权限。本机记录不会丢失。") }
        do { return Self.hash(try await container.userRecordID().recordName) }
        catch { throw StudyConnectionFailure(stage: "连接 iCloud 私有数据库", underlying: error) }
    }

    /// Creating a missing zone is allowed only after a fresh native Apple authorization.
    func authorize(ownerHash: String) async throws -> StudyCloudBinding {
        let owner = try await cloudOwner()
        do { _ = try await database.save(CKRecordZone(zoneID: zone(ownerHash))) }
        catch { throw StudyConnectionFailure(stage: "建立 iCloud 学习空间", underlying: error) }
        let metadata: CKRecord
        do { metadata = try await database.record(for: metaID(ownerHash)) }
        catch let error as CKError where error.code == .unknownItem {
            let created = CKRecord(recordType: "LEAccount", recordID: metaID(ownerHash))
            created.encryptedValues["epoch"] = UUID().uuidString as CKRecordValue
            do { metadata = try await database.save(created) }
            catch let conflict as CKError where conflict.code == .serverRecordChanged {
                guard let server = conflict.serverRecord else { throw conflict }; metadata = server
            }
            catch { throw StudyConnectionFailure(stage: "创建云端学习账户", underlying: error) }
        }
        catch { throw StudyConnectionFailure(stage: "读取云端学习账户", underlying: error) }
        guard let epoch = metadata.encryptedValues["epoch"] as? String else { throw StudyError.message("云端账户数据格式无效，请稍后重试。") }
        return StudyCloudBinding(appleOwnerHash: ownerHash, cloudOwner: owner, epoch: epoch)
    }

    private func require(_ binding: StudyCloudBinding) async throws -> CKRecord {
        guard try await cloudOwner() == binding.cloudOwner else { throw StudyCloudIdentityError.ownerChanged }
        let metadata: CKRecord
        do { metadata = try await database.record(for: metaID(binding.appleOwnerHash)) }
        catch let error as CKError where [.unknownItem, .zoneNotFound, .userDeletedZone].contains(error.code) {
            throw StudyCloudIdentityError.accountDeleted
        }
        guard metadata.encryptedValues["epoch"] as? String == binding.epoch else { throw StudyCloudIdentityError.epochChanged }
        return metadata
    }

    private func changes(owner: String, token: CKServerChangeToken?) async throws -> (records: [CKRecord], token: CKServerChangeToken?) {
        let zoneID = zone(owner)
        let box = CloudChanges()
        return try await withCheckedThrowingContinuation { continuation in
            let config = CKFetchRecordZoneChangesOperation.ZoneConfiguration()
            config.previousServerChangeToken = token
            let operation = CKFetchRecordZoneChangesOperation(recordZoneIDs: [zoneID], configurationsByRecordZoneID: [zoneID: config])
            operation.fetchAllChanges = true
            operation.recordWasChangedBlock = { _, result in
                box.update { value in
                    switch result { case .success(let record): value.records.append(record); case .failure(let error): value.error = error }
                }
            }
            operation.recordZoneFetchCompletionBlock = { _, token, _, _, error in
                box.update { $0.token = token; if let error { $0.error = error } }
            }
            operation.fetchRecordZoneChangesCompletionBlock = { error in
                box.update { value in
                    if let failure = value.error ?? error { continuation.resume(throwing: failure) }
                    else { continuation.resume(returning: (value.records, value.token)) }
                }
            }
            self.database.add(operation)
        }
    }

    func pull(_ binding: StudyCloudBinding, token: CKServerChangeToken?) async throws -> StudyCloudPull {
        _ = try await require(binding)
        let result: (records: [CKRecord], token: CKServerChangeToken?)
        do { result = try await changes(owner: binding.appleOwnerHash, token: token) }
        catch let error as CKError where error.code == .changeTokenExpired {
            result = try await changes(owner: binding.appleOwnerHash, token: nil)
        }
        var events: [[String: Any]] = []
        for record in result.records where record.recordType == "LEEvent" {
            guard let payload = record.encryptedValues["payload"] as? Data,
                  payload.count < 900_000,
                  let event = try JSONSerialization.jsonObject(with: payload) as? [String: Any],
                  let id = event["id"] as? String,
                  record.recordID.recordName == "event-" + Self.hash(id) else { throw StudyError.message("云端记录校验失败，未覆盖本机进度。") }
            events.append(event)
        }
        try StudyStorage.validate(events)
        _ = try await require(binding)
        return StudyCloudPull(events: events, token: result.token, knownIDs: Set(events.compactMap { $0["id"] as? String }))
    }

    func push(_ events: [[String: Any]], binding: StudyCloudBinding) async throws {
        try StudyStorage.validate(events)
        for offset in stride(from: 0, to: events.count, by: 150) {
            try Task.checkCancellation()
            let metadata = try await require(binding)
            // Updating metadata in the same atomic batch makes an account epoch change
            // conflict with stale device writes; deleted accounts are never recreated here.
            metadata.encryptedValues["writeStamp"] = UUID().uuidString as CKRecordValue
            let batch = try events[offset..<min(offset + 150, events.count)].map { event -> CKRecord in
                let payload = try JSONSerialization.data(withJSONObject: event, options: [.sortedKeys])
                guard payload.count < 900_000, let id = event["id"] as? String else { throw StudyError.message("一条学习记录过大，已保存在本机，暂未同步。") }
                let record = CKRecord(recordType: "LEEvent", recordID: CKRecord.ID(recordName: "event-" + Self.hash(id), zoneID: zone(binding.appleOwnerHash)))
                record.encryptedValues["payload"] = payload as CKRecordValue
                return record
            }
            let result = try await database.modifyRecords(saving: batch + [metadata], deleting: [], savePolicy: .ifServerRecordUnchanged, atomically: true)
            for value in result.saveResults.values { _ = try value.get() }
        }
    }

    func delete(_ binding: StudyCloudBinding) async throws {
        guard try await cloudOwner() == binding.cloudOwner else { throw StudyError.message("请恢复原 iCloud 账户后完成注销。") }
        do { _ = try await database.deleteRecordZone(withID: zone(binding.appleOwnerHash)) }
        catch let error as CKError where [.zoneNotFound, .userDeletedZone].contains(error.code) { return }
    }
}
