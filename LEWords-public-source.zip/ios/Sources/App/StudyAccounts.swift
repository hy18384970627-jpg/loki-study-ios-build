import Foundation
import CryptoKit

struct StudyAccount: Codable, Identifiable {
    let id: String
    var name: String
    let createdAt: String
    var appleOwnerHash: String? = nil
}

struct StudyAccountIndex: Codable {
    var activeID: String
    var accounts: [StudyAccount]
}

final class StudyAccountStore {
    let root: URL
    private let lock = NSRecursiveLock()
    private let files = FileManager.default

    init(root: URL) { self.root = root }

    private func locked<T>(_ work: () throws -> T) rethrows -> T {
        lock.lock(); defer { lock.unlock() }
        return try work()
    }

    private func validate(_ index: StudyAccountIndex) throws {
        guard !index.accounts.isEmpty, index.accounts.count <= 30,
              Set(index.accounts.map(\.id)).count == index.accounts.count,
              index.accounts.contains(where: { $0.id == index.activeID }),
              index.accounts.allSatisfy({ UUID(uuidString: $0.id) != nil && !$0.name.isEmpty && $0.name.count <= 24 }) else {
            throw StudyError.message("本机账号目录无效，原学习文件已保留。")
        }
    }

    private func write(_ index: StudyAccountIndex) throws {
        try validate(index)
        try files.createDirectory(at: root, withIntermediateDirectories: true)
        var options: Data.WritingOptions = [.atomic]
        #if os(iOS)
        options.insert(.completeFileProtection)
        #endif
        try JSONEncoder().encode(index).write(to: root.appendingPathComponent("accounts.json"), options: options)
    }

    private func account(_ name: String) -> StudyAccount {
        StudyAccount(id: UUID().uuidString, name: name, createdAt: ISO8601DateFormatter().string(from: Date()))
    }

    private func read() throws -> StudyAccountIndex {
        let file = root.appendingPathComponent("accounts.json")
        if !files.fileExists(atPath: file.path) {
            let initial = account("我的账号")
            let index = StudyAccountIndex(activeID: initial.id, accounts: [initial])
            try write(index)
            return index
        }
        let index = try JSONDecoder().decode(StudyAccountIndex.self, from: Data(contentsOf: file))
        try validate(index)
        return index
    }

    private func cleanName(_ value: String, excluding id: String?, in index: StudyAccountIndex) throws -> String {
        let name = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name.count <= 24, !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw StudyError.message("账号名称须为 1—24 个字符。")
        }
        guard !index.accounts.contains(where: { $0.id != id && $0.name.compare(name, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame }) else {
            throw StudyError.message("这个本机账号名称已存在。")
        }
        return name
    }

    func snapshot() throws -> StudyAccountIndex { try locked { try read() } }
    func active() throws -> StudyAccount {
        try locked {
            let index = try read()
            return index.accounts.first(where: { $0.id == index.activeID })!
        }
    }

    func requireActive(_ identifier: Any?) throws {
        guard let identifier = identifier as? String, identifier == (try active()).id else {
            throw StudyError.message("账号已切换，旧页面的保存请求已取消；请在当前账号重试。")
        }
    }

    private func folder(_ id: String) throws -> URL {
        guard let uuid = UUID(uuidString: id) else { throw StudyError.message("账号编号无效。") }
        return root.appendingPathComponent("profiles", isDirectory: true).appendingPathComponent(uuid.uuidString, isDirectory: true)
    }

    func activeFolder() throws -> URL {
        try locked {
            let url = try folder(active().id)
            #if os(iOS)
            try files.createDirectory(at: url, withIntermediateDirectories: true, attributes: [.protectionKey: FileProtectionType.complete])
            #else
            try files.createDirectory(at: url, withIntermediateDirectories: true)
            #endif
            return url
        }
    }

    @discardableResult func create(_ value: String) throws -> StudyAccount {
        try locked {
            var index = try read()
            guard index.accounts.count < 30 else { throw StudyError.message("本机最多保存 30 个账号。") }
            let new = account(try cleanName(value, excluding: nil, in: index))
            index.accounts.append(new); index.activeID = new.id
            try write(index)
            return new
        }
    }

    func select(_ id: String) throws {
        try locked {
            var index = try read()
            guard index.accounts.contains(where: { $0.id == id }) else { throw StudyError.message("本机账号不存在。") }
            index.activeID = id; try write(index)
        }
    }

    /// Only native Apple authorization calls this; the web bridge cannot choose owners.
    func activateApple(ownerHash: String) throws -> StudyAccount {
        try locked {
            guard ownerHash.count == 64, ownerHash.allSatisfy({ $0.isHexDigit }) else { throw StudyError.message("Apple 账户标识无效。") }
            var index = try read()
            if let existing = index.accounts.first(where: { $0.appleOwnerHash == ownerHash }) {
                index.activeID = existing.id; try write(index); return existing
            }
            let digest = Array(SHA256.hash(data: Data(("LE-Apple-" + ownerHash).utf8)))
            let bytes = Array(digest.prefix(16))
            let id = UUID(uuid: (bytes[0],bytes[1],bytes[2],bytes[3],bytes[4],bytes[5],bytes[6],bytes[7],bytes[8],bytes[9],bytes[10],bytes[11],bytes[12],bytes[13],bytes[14],bytes[15])).uuidString
            guard index.accounts.count < 30 else { throw StudyError.message("本机保留档案过多，请先导出需要保留的旧档案。") }
            let new = StudyAccount(id: id, name: "Apple 账户", createdAt: ISO8601DateFormatter().string(from: Date()), appleOwnerHash: ownerHash)
            index.accounts.append(new); index.activeID = id; try write(index); return new
        }
    }

    func activateGuest() throws -> StudyAccount {
        try locked {
            var index = try read()
            let key = "LE.guestProfileID.v1"
            let saved = UserDefaults.standard.string(forKey: key)
            let guest = index.accounts.first(where: { $0.id == saved && $0.appleOwnerHash == nil })
                ?? index.accounts.first(where: { $0.id == index.activeID && $0.appleOwnerHash == nil })
                ?? index.accounts.first(where: { $0.appleOwnerHash == nil })
            let chosen: StudyAccount
            if let guest { chosen = guest }
            else {
                guard index.accounts.count < 30 else { throw StudyError.message("请先导出需要保留的旧档案。") }
                chosen = account("游客档案"); index.accounts.append(chosen)
            }
            index.activeID = chosen.id; try write(index)
            UserDefaults.standard.set(chosen.id, forKey: key)
            return chosen
        }
    }

    func requireOwner(_ hash: String?) throws {
        guard try active().appleOwnerHash == hash else { throw StudyError.message("学习档案状态已变化，请重新打开应用；原记录仍保留。") }
    }

    func renameActive(_ value: String) throws {
        try locked {
            var index = try read()
            let name = try cleanName(value, excluding: index.activeID, in: index)
            let position = index.accounts.firstIndex(where: { $0.id == index.activeID })!
            index.accounts[position].name = name; try write(index)
        }
    }

    func deleteActive() throws {
        try locked {
            let before = try read()
            let oldFolder = try folder(before.activeID)
            var remaining = before.accounts.filter { $0.id != before.activeID }
            if !remaining.contains(where: { $0.appleOwnerHash == nil }) { remaining.append(account("游客档案")) }
            let after = StudyAccountIndex(activeID: remaining.first(where: { $0.appleOwnerHash == nil })!.id, accounts: remaining)
            try write(after)
            do {
                if files.fileExists(atPath: oldFolder.path) { try files.removeItem(at: oldFolder) }
                UserDefaults.standard.removeObject(forKey: "studyReminder." + before.activeID)
            } catch {
                try write(before)
                throw error
            }
        }
    }
}

enum StudyAccounts {
    static let shared: StudyAccountStore = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return StudyAccountStore(root: base.appendingPathComponent("LEStudyAccounts", isDirectory: true))
    }()
    static var reminderKey: String { "studyReminder." + ((try? shared.active().id) ?? "unavailable") }
}
