import Foundation
import Combine
import AuthenticationServices
import Security
import CloudKit
import Network

private struct AppleStudySession: Codable {
    let user: String
    let profileID: String
    let binding: StudyCloudBinding
    var deletionPending = false
}

private struct CloudCheckpoint: Codable {
    let binding: StudyCloudBinding
    var token: Data?
    var knownIDs: Set<String> = []
    var syncedAt: Date?
}

private enum AppleStudyKeychain {
    private static let base: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
        kSecAttrService as String: "dev.zcydrkv7yh.lewords.auth", kSecAttrAccount as String: "apple-session-v1"]
    static func read() throws -> AppleStudySession? {
        var query = base; query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else { throw StudyError.message("账户凭据暂不可读，请解锁设备后重试。") }
        return try JSONDecoder().decode(AppleStudySession.self, from: data)
    }
    static func write(_ session: AppleStudySession) throws {
        let data = try JSONEncoder().encode(session)
        let update = [kSecValueData as String: data, kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly] as [String: Any]
        var status = SecItemUpdate(base as CFDictionary, update as CFDictionary)
        if status == errSecItemNotFound {
            var item = base; update.forEach { item[$0] = $1 }; status = SecItemAdd(item as CFDictionary, nil)
        }
        guard status == errSecSuccess else { throw StudyError.message("账户凭据保存失败，未切换学习档案。") }
    }
    static func remove() throws {
        let status = SecItemDelete(base as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw StudyError.message("退出登录暂未完成，请解锁后重试。") }
    }
}

@MainActor final class StudyIdentity: ObservableObject {
    static let shared = StudyIdentity()
    @Published private(set) var ready = false
    @Published private(set) var signedIn = false
    @Published private(set) var syncing = false
    @Published private(set) var status = "游客模式 · 仅保存在本机"
    @Published private(set) var lastSynced: Date?
    @Published private(set) var canImportGuest = false
    @Published private(set) var deletionPending = false
    @Published private(set) var hasStaleCache = false
    @Published private(set) var networkStatus = "正在检查网络"
    var accountChanged: (() -> Void)?
    var cloudChanged: (() -> Void)?
    var cacheDeleted: ((String) -> Void)?
    private var session: AppleStudySession?
    private var guestID = ""
    private var epoch = 0
    private var queuedSync: Task<Void, Never>?
    private var foregroundRefresh: Task<Void, Never>?
    private var needsSync = false
    private var monitor: NWPathMonitor?
    private var observations: [NSObjectProtocol] = []
    private var deferredImport: [[String: Any]] = []
    private var revoking = false
    private var staleUser: String?
    var foreground = true
    var ownerHash: String? { session?.binding.appleOwnerHash }

    private func credentialState(_ user: String) async throws -> ASAuthorizationAppleIDProvider.CredentialState {
        try await withCheckedThrowingContinuation { continuation in
            ASAuthorizationAppleIDProvider().getCredentialState(forUserID: user) { state, error in
                if let error { continuation.resume(throwing: error) } else { continuation.resume(returning: state) }
            }
        }
    }

    func bootstrap() async {
        guard !ready else { return }
        do {
            guestID = try StudyAccounts.shared.activateGuest().id
            if let saved = try AppleStudyKeychain.read() {
                let state = try? await credentialState(saved.user)
                if saved.deletionPending || state == .authorized || state == nil {
                    let active = try StudyAccounts.shared.activateApple(ownerHash: saved.binding.appleOwnerHash)
                    guard active.id == saved.profileID else { throw StudyError.message("账户档案标识不一致。") }
                    session = saved; signedIn = true; deletionPending = saved.deletionPending
                    status = saved.deletionPending ? "注销处理中，已停止同步" : "进度已保存在本机，正在连接 iCloud"
                } else { try AppleStudyKeychain.remove() }
            }
            ready = true; observeAccounts()
            if deletionPending { await finishDeletion() } else { scheduleSync() }
        } catch { status = error.localizedDescription; ready = true }
    }

    private func observeAccounts() {
        guard monitor == nil else { return }
        let path = NWPathMonitor(); monitor = path
        path.pathUpdateHandler = { [weak self] value in
            let text: String
            if value.status == .satisfied {
                text = value.usesInterfaceType(.wifi) ? "网络可用 · 无线局域网" : "网络可用"
            } else {
                switch value.unsatisfiedReason {
                case .wifiDenied: text = "无线局域网访问被系统拒绝，请检查 LE 单词的无线数据权限。"
                case .cellularDenied: text = "蜂窝数据访问被系统拒绝，请检查 LE 单词的无线数据权限。"
                default: text = "此 App 当前没有可用网络，请检查系统网络与应用权限。"
                }
            }
            Task { @MainActor in
                self?.networkStatus = text
                if value.status == .satisfied { self?.scheduleSync() }
            }
        }
        path.start(queue: DispatchQueue(label: "le.network-status"))
        foregroundRefresh = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(30))
                guard !Task.isCancelled else { return }
                if let self, self.foreground { await self.sync() }
            }
        }
        observations.append(NotificationCenter.default.addObserver(forName: ASAuthorizationAppleIDProvider.credentialRevokedNotification, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in await self?.refreshAuthorization() }
        })
        observations.append(NotificationCenter.default.addObserver(forName: .CKAccountChanged, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                self.queuedSync?.cancel()
                if self.deletionPending { self.status = "请恢复原 iCloud 账户后继续完成注销。"; return }
                if self.signedIn {
                    try? self.logout()
                    self.status = "系统 iCloud 账户已变化，请重新使用 Apple 登录。原账户缓存仍保留。"
                }
            }
        })
    }

    func refreshAuthorization() async {
        guard !revoking else { return }
        guard let saved = session else { return }
        if saved.deletionPending { await finishDeletion(); return }
        do {
            let state = try await credentialState(saved.user)
            if state != .authorized {
                try logout(); status = "Apple 授权已失效，请重新登录；本机待同步记录仍保留。"
            }
        } catch { status = "暂时无法核对 Apple 授权，进度已保存在本机。" }
    }

    func authorize(_ credential: ASAuthorizationAppleIDCredential) async throws {
        guard !credential.user.isEmpty, credential.identityToken != nil else { throw StudyError.message("Apple 未返回有效授权，请重试。") }
        let state: ASAuthorizationAppleIDProvider.CredentialState
        do { state = try await credentialState(credential.user) }
        catch { throw StudyConnectionFailure(stage: "核对 Apple 登录授权", underlying: error) }
        guard state == .authorized else { throw StudyError.message("Apple 授权未完成。") }
        let guest = try StudyAccounts.shared.activateGuest()
        guestID = guest.id
        let guestFile = try StudyAccounts.shared.activeFolder().appendingPathComponent("events.json")
        let guestEvents: [[String: Any]]
        if FileManager.default.fileExists(atPath: guestFile.path) {
            guestEvents = (try JSONSerialization.jsonObject(with: Data(contentsOf: guestFile)) as? [[String: Any]]) ?? []
            try StudyStorage.validate(guestEvents)
        } else { guestEvents = [] }
        let hash = CloudStudySync.hash(credential.user)
        let binding = try await CloudStudySync.shared.authorize(ownerHash: hash)
        let previous = try StudyAccounts.shared.active()
        let active = try StudyAccounts.shared.activateApple(ownerHash: hash)
        do {
            if let state = try checkpoint(), state.binding != binding {
                staleUser = credential.user; hasStaleCache = true
                throw StudyError.message("此账户的云端档案已重建。旧记录已留在本机，未自动上传；请先导出并清理旧缓存后重新登录。")
            }
            let saved = AppleStudySession(user: credential.user, profileID: active.id, binding: binding)
            try AppleStudyKeychain.write(saved)
            epoch += 1; session = saved; signedIn = true; deletionPending = false
            staleUser = nil; hasStaleCache = false
            deferredImport = guestEvents; canImportGuest = !guestEvents.isEmpty
            status = "已使用 Apple 登录，正在恢复云端进度"
            accountChanged?(); await sync()
        } catch { try? StudyAccounts.shared.select(previous.id); throw error }
    }

    func requireActiveOwner() throws {
        guard ready, !deletionPending, !revoking else { throw StudyError.message("账户正在初始化或注销，暂不接受新的学习记录。") }
        try StudyAccounts.shared.requireOwner(ownerHash)
        if let session { guard try StudyAccounts.shared.active().id == session.profileID else { throw StudyError.message("请重新打开当前账户。") } }
    }

    private func checkpointURL() throws -> URL { try StudyAccounts.shared.activeFolder().appendingPathComponent("cloud-checkpoint-v1.json") }
    private func checkpoint() throws -> CloudCheckpoint? {
        let url = try checkpointURL()
        return FileManager.default.fileExists(atPath: url.path) ? try JSONDecoder().decode(CloudCheckpoint.self, from: Data(contentsOf: url)) : nil
    }
    private func write(_ value: CloudCheckpoint) throws {
        try JSONEncoder().encode(value).write(to: checkpointURL(), options: [.atomic, .completeFileProtection])
    }

    func scheduleSync() {
        guard signedIn, !deletionPending, foreground else { return }
        queuedSync?.cancel()
        queuedSync = Task { [weak self] in
            try? await Task.sleep(for: .seconds(2))
            guard !Task.isCancelled else { return }
            await self?.sync()
        }
    }

    func sync() async {
        guard let saved = session, signedIn, !deletionPending, foreground else { return }
        if syncing { needsSync = true; return }
        let captured = epoch
        syncing = true; status = "正在同步学习进度"
        defer {
            syncing = false
            if needsSync { needsSync = false; scheduleSync() }
        }
        do {
            try requireActiveOwner()
            var state = try checkpoint() ?? CloudCheckpoint(binding: saved.binding)
            guard state.binding == saved.binding else { throw StudyError.message("本机缓存属于旧的账户档案，已停止上传。") }
            let token = try state.token.flatMap { try NSKeyedUnarchiver.unarchivedObject(ofClass: CKServerChangeToken.self, from: $0) }
            let pull = try await CloudStudySync.shared.pull(saved.binding, token: token)
            guard epoch == captured, session?.profileID == saved.profileID, !deletionPending else { return }
            try requireActiveOwner()
            let merged = try StudyStorage.save(pull.events)
            state.knownIDs.formUnion(pull.knownIDs)
            state.token = try pull.token.map { try NSKeyedArchiver.archivedData(withRootObject: $0, requiringSecureCoding: true) }
            try write(state) // Advance the server token only after the local atomic merge.
            let pending = merged.filter { !state.knownIDs.contains($0["id"] as? String ?? "") }
            if !pending.isEmpty { try await CloudStudySync.shared.push(pending, binding: saved.binding) }
            guard epoch == captured, session?.profileID == saved.profileID, !deletionPending else { return }
            state.knownIDs.formUnion(pending.compactMap { $0["id"] as? String })
            state.syncedAt = Date(); try write(state); lastSynced = state.syncedAt
            status = "已与 iCloud 同步"
            let latest = try StudyStorage.events()
            needsSync = latest.contains { !state.knownIDs.contains($0["id"] as? String ?? "") }
            cloudChanged?()
        } catch {
            guard epoch == captured else { return }
            if let error = error as? StudyCloudIdentityError {
                let user = saved.user
                try? logout()
                if error != .ownerChanged { staleUser = user; hasStaleCache = true }
                status = error.localizedDescription
            }
            else if let error = error as? CKError, error.code == .quotaExceeded { status = "iCloud 空间不足，新增进度已保存在本机，尚未上传。" }
            else { status = "本机记录已保留 · " + error.localizedDescription }
        }
    }

    func importGuest() throws {
        try requireActiveOwner()
        guard signedIn else { throw StudyError.message("请先登录 Apple 账户。") }
        _ = try StudyStorage.save(deferredImport)
        deferredImport = []; canImportGuest = false; accountChanged?(); scheduleSync()
    }

    func logout() throws {
        guard !deletionPending else { throw StudyError.message("注销正在处理中，完成后会自动退出。") }
        epoch += 1; queuedSync?.cancel(); needsSync = false
        try AppleStudyKeychain.remove()
        session = nil; signedIn = false; canImportGuest = false; deferredImport = []; lastSynced = nil
        guestID = try StudyAccounts.shared.activateGuest().id
        status = "游客模式 · 仅保存在本机"; accountChanged?()
    }

    func clearStaleCache() async throws {
        guard !signedIn, let user = staleUser,
              try await credentialState(user) == .authorized else { throw StudyError.message("请先重新使用原 Apple 账户验证身份。") }
        let account = try StudyAccounts.shared.activateApple(ownerHash: CloudStudySync.hash(user))
        try StudyAccounts.shared.deleteActive()
        _ = try StudyAccounts.shared.activateGuest()
        staleUser = nil; hasStaleCache = false
        cacheDeleted?(account.id); accountChanged?()
        status = "已清除此设备失效的旧缓存，可以重新登录并恢复云端进度。"
    }

    /// A fresh native Apple authorization supplies the single-use code. The
    /// companion service exchanges and revokes it without storing user tokens.
    func deleteAccount(credential: ASAuthorizationAppleIDCredential) async throws {
        guard var saved = session, credential.user == saved.user,
              let code = credential.authorizationCode, let string = String(data: code, encoding: .utf8) else { throw StudyError.message("请使用当前 Apple 账户确认注销。") }
        guard let address = Bundle.main.object(forInfoDictionaryKey: "LEAppleAccountServiceURL") as? String,
              let url = URL(string: address), url.scheme == "https", url.host != nil else { throw StudyError.message("账户注销服务尚未配置，未删除你的记录。") }
        epoch += 1; queuedSync?.cancel(); status = "正在撤销 Apple 授权"
        revoking = true
        defer { revoking = false }
        var request = URLRequest(url: url.appendingPathComponent("apple/revoke")); request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["code": string, "user": saved.user])
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200,
              (try JSONSerialization.jsonObject(with: data) as? [String: Any])?["revoked"] as? Bool == true else { throw StudyError.message("Apple 授权撤销尚未完成，账户记录仍保留，请稍后重试。") }
        saved.deletionPending = true; try AppleStudyKeychain.write(saved)
        session = saved; deletionPending = true
        await finishDeletion()
    }

    private func finishDeletion() async {
        guard let saved = session, saved.deletionPending else { return }
        do {
            try await CloudStudySync.shared.delete(saved.binding)
            guard session?.profileID == saved.profileID else { return }
            _ = try StudyAccounts.shared.activateApple(ownerHash: saved.binding.appleOwnerHash)
            try StudyAccounts.shared.deleteActive()
            try AppleStudyKeychain.remove()
            epoch += 1; session = nil; signedIn = false; deletionPending = false; canImportGuest = false; deferredImport = []
            guestID = try StudyAccounts.shared.activateGuest().id
            status = "账户及云端学习记录已删除"; cacheDeleted?(saved.profileID); accountChanged?()
        } catch { status = "注销处理中，记录不会继续同步。请联网并恢复原 iCloud 账户后重试。" }
    }
}
