import UIKit
import WebKit

final class StudyWindowContainer: UIView {
    let web: WKWebView
    init(web: WKWebView) {
        self.web = web
        super.init(frame: .zero)
        backgroundColor = UIColor(red: 0.047, green: 0.082, blue: 0.071, alpha: 1)
        clipsToBounds = true
        addSubview(web)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
    override func safeAreaInsetsDidChange() { super.safeAreaInsetsDidChange(); setNeedsLayout() }
    override func layoutSubviews() {
        super.layoutSubviews()
        let available = bounds.inset(by: safeAreaInsets)
        guard available.width > 0, available.height > 0 else { return }
        var divisions: [CGRect] = []
        if #available(iOS 27.1, *) {
            // Reading during layout lets UIKit schedule a new layout when the fold changes.
            divisions = reservedRegions(kind: .division).filter(\.isActive).map(\.frame)
        }
        let target = StudyPaneLayout.pane(in: available, divisions: divisions)
        if web.frame != target { web.frame = target }
    }
}
