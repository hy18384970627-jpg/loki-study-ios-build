import UIKit
import WebKit

final class StudyWindowContainer: UIView {
    let web: WKWebView
    private var divisions: [CGRect] = []
    init(web: WKWebView) {
        self.web = web
        super.init(frame: .zero)
        backgroundColor = UIColor(red: 0.047, green: 0.082, blue: 0.071, alpha: 1)
        clipsToBounds = true
        addSubview(web)
        setNeedsUpdateConstraints()
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
    override func safeAreaInsetsDidChange() {
        super.safeAreaInsetsDidChange()
        setNeedsUpdateConstraints()
        setNeedsLayout()
    }
    override func updateConstraints() {
        if #available(iOS 27.1, *) {
            // UIKit tracks these reads and re-runs updateConstraints when the fold changes.
            let regions = reservedRegions(kind: .division).map(\.frame)
            if divisions != regions { divisions = regions; setNeedsLayout() }
        }
        super.updateConstraints()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        let available = bounds.inset(by: safeAreaInsets)
        guard available.width > 0, available.height > 0 else { return }
        let target = StudyPaneLayout.pane(in: available, divisions: divisions)
        if web.frame != target { web.frame = target }
    }
}
