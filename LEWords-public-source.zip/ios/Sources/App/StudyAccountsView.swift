import SwiftUI

struct StudyAccountsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var accounts: [StudyAccount] = []
    @State private var activeID = ""
    @State private var newName = ""
    @State private var currentName = ""
    @State private var message = ""
    @State private var confirmDeletion = false
    let changed: () -> Void
    let deleted: (String) -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section("切换本机账号") {
                    ForEach(accounts) { account in
                        Button {
                            perform { try StudyAccounts.shared.select(account.id); changed(); dismiss() }
                        } label: {
                            HStack {
                                Text(account.name)
                                Spacer()
                                if account.id == activeID { Image(systemName: "checkmark") }
                            }
                        }
                    }
                }
                Section("新建账号") {
                    TextField("账号名称", text: $newName)
                    Button("创建并切换") {
                        perform { try StudyAccounts.shared.create(newName); changed(); dismiss() }
                    }
                }
                Section("管理当前账号") {
                    TextField("账号名称", text: $currentName)
                    Button("保存名称") { perform { try StudyAccounts.shared.renameActive(currentName); reload(); changed() } }
                    Button("删除当前账号及学习记录", role: .destructive) { confirmDeletion = true }
                }
                Section {
                    Text("每个账号分别保存背词记录、复习计划、生词本和学习设置。账号仅存在于这台 iPhone，不提供云同步或远程登录。切换账号会重新载入对应档案。")
                    Text("同一台 iPhone 上的档案可以在这里切换；这不是密码登录系统。卸载前请导出需要保留的学习备份。系统专注权限对本机生效。")
                }
                if !message.isEmpty { Text(message).foregroundStyle(.red) }
            }
            .navigationTitle("学习账号")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
            .onAppear { reload() }
            .alert("删除当前账号？", isPresented: $confirmDeletion) {
                Button("取消", role: .cancel) {}
                Button("删除", role: .destructive) {
                    perform {
                        let oldID = try StudyAccounts.shared.active().id
                        try StudyAccounts.shared.deleteActive()
                        deleted(oldID); dismiss()
                    }
                }
            } message: { Text("当前账号的学习记录和本机备份将被删除，其他账号不受影响。没有云端副本可供恢复。") }
        }
    }

    private func perform(_ work: () throws -> Void) {
        do { try work() } catch { message = error.localizedDescription }
    }
    private func reload() {
        perform {
            let index = try StudyAccounts.shared.snapshot()
            accounts = index.accounts; activeID = index.activeID
            currentName = accounts.first(where: { $0.id == activeID })?.name ?? ""
        }
    }
}
