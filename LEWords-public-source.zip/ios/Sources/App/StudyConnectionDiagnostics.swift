import Foundation

struct StudyConnectionFailure: LocalizedError {
    let stage: String
    let underlying: Error
    var errorDescription: String? {
        let value = underlying as NSError
        return "\(stage)：\(value.localizedDescription)（\(value.domain) \(value.code)）"
    }
}

enum StudyConnectionDiagnostics {
    static func capture(_ error: Error, network: String) {
        let failure = error as? StudyConnectionFailure
        let root = (failure?.underlying ?? error) as NSError
        var codes: [[String: Any]] = []
        var current: NSError? = root
        for _ in 0..<4 {
            guard let value = current else { break }
            codes.append(["domain": value.domain, "code": value.code])
            current = value.userInfo[NSUnderlyingErrorKey] as? NSError
        }
        // Deliberately omit messages, URLs, Apple identifiers, tokens and request bodies.
        let record: [String: Any] = ["at": ISO8601DateFormatter().string(from: Date()), "stage": failure?.stage ?? "Apple 系统授权", "network": network, "errors": codes]
        do {
            let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            let folder = base.appendingPathComponent("LEAccountDiagnostics", isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            try JSONSerialization.data(withJSONObject: record, options: [.sortedKeys]).write(to: folder.appendingPathComponent("last-error.json"), options: [.atomic, .completeFileProtection])
        } catch { /* Diagnostics must never prevent offline learning. */ }
    }
}
