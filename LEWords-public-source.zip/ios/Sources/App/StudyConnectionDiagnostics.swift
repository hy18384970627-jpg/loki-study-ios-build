import Foundation
import CloudKit

struct StudyConnectionFailure: LocalizedError {
    let stage: String
    let underlying: Error
    var errorDescription: String? {
        if StudyConnectionDiagnostics.isQuotaFailure(underlying) {
            return "iCloud 可用空间不足，暂时无法创建或更新云端学习记录。本机进度仍保留。请在系统设置的 iCloud 中检查空间，调整后等待数分钟再重试。"
        }
        let value = underlying as NSError
        return "\(stage)：\(value.localizedDescription)（\(value.domain) \(value.code)）"
    }
}

enum StudyConnectionDiagnostics {
    static func isQuotaFailure(_ error: Error, depth: Int = 0) -> Bool {
        guard depth < 8 else { return false }
        if let failure = error as? StudyConnectionFailure { return isQuotaFailure(failure.underlying, depth: depth + 1) }
        let value = error as NSError
        if (value.domain == CKErrorDomain && value.code == CKError.quotaExceeded.rawValue)
            || (value.domain == "CKInternalErrorDomain" && value.code == 2035) { return true }
        if let nested = value.userInfo[NSUnderlyingErrorKey] as? Error,
           isQuotaFailure(nested, depth: depth + 1) { return true }
        if let partial = value.userInfo[CKPartialErrorsByItemIDKey] as? [AnyHashable: Error] {
            return partial.values.contains { isQuotaFailure($0, depth: depth + 1) }
        }
        return false
    }

    static func capture(_ error: Error, network: String) {
        let failure = error as? StudyConnectionFailure
        let root = (failure?.underlying ?? error) as NSError
        var codes: [[String: Any]] = []
        var current: NSError? = root
        for _ in 0..<4 {
            guard let value = current else { break }
            codes.append(["domain": value.domain, "code": value.code])
            current = value.userInfo[NSUnderlyingErrorKey] as? NSError
        }
        // Deliberately omit messages, URLs, Apple identifiers, tokens and request bodies.
        let record: [String: Any] = ["at": ISO8601DateFormatter().string(from: Date()), "stage": failure?.stage ?? "Apple 系统授权", "network": network, "errors": codes, "quotaExceeded": isQuotaFailure(error)]
        do {
            let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            let folder = base.appendingPathComponent("LEAccountDiagnostics", isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            try JSONSerialization.data(withJSONObject: record, options: [.sortedKeys]).write(to: folder.appendingPathComponent("last-error.json"), options: [.atomic, .completeFileProtection])
        } catch { /* Diagnostics must never prevent offline learning. */ }
    }
}
