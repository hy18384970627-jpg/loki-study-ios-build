import SwiftUI
import WebKit
import UserNotifications
import AVFoundation

@main struct LokiStudyApp: App {
    @StateObject private var bridge = StudyBridge()
    var body: some Scene {
        WindowGroup {
            StudyWebView(bridge: bridge)
                .background(Color(red: 0.047, green: 0.082, blue: 0.071))
                .preferredColorScheme(.dark)
                .task {
                    try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
                    if bridge.storageReady, let time = UserDefaults.standard.string(forKey: StudyAccounts.reminderKey) {
                        if let account = try? StudyAccounts.shared.active() {
                            _ = try? await bridge.invoke("reminder", ["time": time, "profileId": account.id])
                        }
                    }
                }
        }
    }
}


@MainActor final class StudyBridge: NSObject, ObservableObject, WKScriptMessageHandler, WKNavigationDelegate, WKDownloadDelegate {
    weak var web: WKWebView?
    private(set) var storageReady = false
    override init() {
        super.init()
        do { _ = try StudyAccounts.shared.activateGuest(); storageReady = true }
        catch { storageReady = false }
    }
    private var speaking = false
    private var exportFile: URL?
    private var webRoot: URL? { Bundle.main.url(forResource: "web", withExtension: nil) }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "study", message.frameInfo.isMainFrame,
              let url = message.frameInfo.request.url, isLocal(url),
              let body = message.body as? [String: Any], let id = body["id"] as? String, UUID(uuidString: id) != nil,
              let method = body["method"] as? String else { return }
        Task {
            do { reply(id, ["ok": true, "result": try await invoke(method, body["params"] as? [String: Any] ?? [:])]) }
            catch { reply(id, ["ok": false, "error": error.localizedDescription]) }
        }
    }
    func isLocal(_ url: URL) -> Bool {
        guard url.isFileURL, let root = webRoot else { return false }
        return url.standardizedFileURL.path.hasPrefix(root.standardizedFileURL.path + "/")
    }
    func reply(_ id: String, _ value: [String: Any]) {
        let safeValue: [String: Any] = JSONSerialization.isValidJSONObject(value) ? value : ["ok": false, "error": "响应数据格式无效，原记录已保留。"]
        guard let json = try? JSONSerialization.data(withJSONObject: ["id": id, "value": safeValue]),
              let encoded = String(data: json, encoding: .utf8) else { return }
        web?.evaluateJavaScript("{const r=\(encoded);window.StudyNative?.receive(r.id,r.value);}", completionHandler: nil)
    }
    func summarize(_ events: [[String: Any]]) {
        UserDefaults.standard.removeObject(forKey: "LECompletedStudyDay")
        let day = StudyDates.day()
        let rows = events.filter { $0["kind"] as? String == "plan" && $0["day"] as? String == day }
        guard let baseRow = rows.last(where: { ($0["payload"] as? [String: Any])?["supplement"] as? Bool != true }),
              let base = baseRow["payload"] as? [String: Any] else { return }
        let plans = rows.filter { ($0["at"] as? String ?? "") >= (baseRow["at"] as? String ?? "") }.compactMap { $0["payload"] as? [String: Any] }
        let extra = plans.filter { $0["supplement"] as? Bool == true }.flatMap { $0["new"] as? [String] ?? [] }
        let words = Set((base["review"] as? [String] ?? []) + (base["new"] as? [String] ?? []) + extra)
        var flags: [String: Bool] = [:]
        for e in events where e["kind"] as? String == "settings" {
            for (id, value) in (e["payload"] as? [String: Any])?["wordFlags"] as? [String: Bool] ?? [:] { flags[id] = value }
        }
        var latest: [String: Bool] = [:]
        for e in events where e["kind"] as? String == "review" && e["day"] as? String == day {
            if e["purpose"] as? String == "practice" { continue }
            if let word = e["word"] as? String, words.contains(word), let rating = e["rating"] as? Int, (1...4).contains(rating) {
                let card = e["cardAfter"] as? [String: Any]
                latest[word] = rating >= 3 && (card == nil || card?["state"] as? Int == 2)
            }
        }
        let remaining = words.filter { flags[$0] != true && latest[$0] != true }.count
        if !words.isEmpty && remaining == 0 { UserDefaults.standard.set(day, forKey: "LECompletedStudyDay") }
        if !words.isEmpty && remaining == 0 {
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["LokiStudy-reminder-" + StudyStorage.deviceID + "-" + day])
        }
    }
    func invoke(_ method: String, _ params: [String: Any]) async throws -> [String: Any] {
        guard storageReady else { throw StudyError.message("学习档案暂时无法读取，原记录已保留。请重新打开应用或联系支持。") }
        try StudyAccounts.shared.requireOwner(nil)
        if ["save", "reminder"].contains(method) {
            try StudyAccounts.shared.requireActive(params["profileId"])
        }
        switch method {
        case "load":
            let account = try StudyAccounts.shared.active()
            let events = try StudyStorage.events(); summarize(events)
            return ["events": events, "deviceId": account.id, "profileId": account.id,
                    "profileName": account.name, "status": "学习进度保存在这台设备，请定期导出学习备份。"]
        case "save":
            guard let events = params["events"] as? [[String: Any]] else { throw StudyError.message("缺少学习记录。") }
            let saved = try StudyStorage.save(events); summarize(saved); return ["events": saved]
        case "speak":
            throw StudyError.message("该内容的离线录音尚未收录。")
        case "reminder":
            guard let time = params["time"] as? String else { throw StudyError.message("缺少提醒时间。") }
            let parts = time.split(separator: ":").compactMap { Int($0) }
            guard parts.count == 2, (0...23).contains(parts[0]), (0...59).contains(parts[1]) else { throw StudyError.message("提醒时间格式错误。") }
            let center = UNUserNotificationCenter.current()
            guard try await center.requestAuthorization(options: [.alert, .sound]) else { throw StudyError.message("系统通知未授权，学习计划已保存。") }
            let old = await center.pendingNotificationRequests().filter { $0.identifier.hasPrefix("LokiStudy-reminder-") }.map(\.identifier)
            try StudyAccounts.shared.requireActive(params["profileId"])
            center.removePendingNotificationRequests(withIdentifiers: old)
            let cal = StudyDates.calendar
            for offset in 0..<14 {
                guard let day = cal.date(byAdding: .day, value: offset, to: Date()),
                      let date = cal.date(bySettingHour: parts[0], minute: parts[1], second: 0, of: day), date > Date() else { continue }
                let key = StudyDates.day(date)
                if UserDefaults.standard.string(forKey: "LECompletedStudyDay") == key { continue }
                let content = UNMutableNotificationContent()
                content.title = "LE · 该背词了"
                content.body = "今天的学习任务已准备好，打开 LE 单词继续学习。"
                content.sound = .default
                let components = cal.dateComponents([.timeZone, .year, .month, .day, .hour, .minute], from: date)
                let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
                try StudyAccounts.shared.requireActive(params["profileId"])
                let notificationID = "LokiStudy-reminder-" + StudyStorage.deviceID + "-" + key
                try await center.add(.init(identifier: notificationID, content: content, trigger: trigger))
                do { try StudyAccounts.shared.requireActive(params["profileId"]) }
                catch { center.removePendingNotificationRequests(withIdentifiers: [notificationID]); throw error }
            }
            UserDefaults.standard.set(time, forKey: StudyAccounts.reminderKey)
            return ["scheduled": true, "days": 14]
        default: throw StudyError.message("此版本暂不支持这项原生操作。")
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if navigationAction.navigationType == .linkActivated, url.scheme == "https", url.host == "tatoeba.org" {
            UIApplication.shared.open(url); decisionHandler(.cancel); return
        }
        if navigationAction.shouldPerformDownload && url.scheme == "blob" { decisionHandler(.download); return }
        decisionHandler(isLocal(url) || url.absoluteString == "about:blank" ? .allow : .cancel)
    }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "-LokiStudy.json")
        exportFile = file; completionHandler(file)
    }
    func downloadDidFinish(_ download: WKDownload) {
        guard let file = exportFile, let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              var controller = scene.windows.first(where: \.isKeyWindow)?.rootViewController else { return }
        while let next = controller.presentedViewController { controller = next }
        let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
        share.popoverPresentationController?.sourceView = controller.view
        controller.present(share, animated: true)
    }
}

struct StudyWebView: UIViewRepresentable {
    @ObservedObject var bridge: StudyBridge
    func makeUIView(context: Context) -> StudyWindowContainer {
        let config = WKWebViewConfiguration()
        config.userContentController.add(bridge, name: "study")
        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsInlineMediaPlayback = true
        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = bridge; bridge.web = web
        web.isOpaque = false; web.backgroundColor = UIColor(red: 0.047, green: 0.082, blue: 0.071, alpha: 1)
        if let folder = Bundle.main.url(forResource: "web", withExtension: nil) {
            web.loadFileURL(folder.appendingPathComponent("index.html"), allowingReadAccessTo: folder)
        }
        return StudyWindowContainer(web: web)
    }
    func updateUIView(_ uiView: StudyWindowContainer, context: Context) { uiView.setNeedsLayout() }
}

