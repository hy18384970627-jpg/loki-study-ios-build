import SwiftUI
import WebKit
import FamilyControls
import DeviceActivity
import UserNotifications
import AVFoundation

@main struct LokiStudyApp: App {
    @StateObject private var bridge = StudyBridge()
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            StudyWebView(bridge: bridge)
                .background(Color(red: 0.047, green: 0.082, blue: 0.071))
                .preferredColorScheme(.dark)
                .sheet(item: $bridge.sheet) { item in
                    if item == .accounts { StudyAccountsView(changed: { bridge.accountChanged() }, deleted: { bridge.accountDeleted($0) }) } else { StudyFocusView() }
                }
                .onChange(of: phase) { _, new in if new == .active { StudyFocus.refresh() } }
                .task {
                    try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
                    if let time = UserDefaults.standard.string(forKey: StudyAccounts.reminderKey) {
                        if let account = try? StudyAccounts.shared.active() {
                            _ = try? await bridge.invoke("reminder", ["time": time, "profileId": account.id])
                        }
                    }
                }
        }
    }
}

enum StudySheet: String, Identifiable { case accounts, focus; var id: String { rawValue } }

@MainActor final class StudyBridge: NSObject, ObservableObject, WKScriptMessageHandler, WKNavigationDelegate, WKDownloadDelegate {
    @Published var sheet: StudySheet?
    weak var web: WKWebView?
    private var speaking = false
    private var exportFile: URL?
    private var webRoot: URL? { Bundle.main.url(forResource: "web", withExtension: nil) }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "study", message.frameInfo.isMainFrame,
              let url = message.frameInfo.request.url, isLocal(url),
              let body = message.body as? [String: Any], let id = body["id"] as? String, UUID(uuidString: id) != nil,
              let method = body["method"] as? String else { return }
        Task {
            do { reply(id, ["ok": true, "result": try await invoke(method, body["params"] as? [String: Any] ?? [:])]) }
            catch { reply(id, ["ok": false, "error": error.localizedDescription]) }
        }
    }
    func isLocal(_ url: URL) -> Bool {
        guard url.isFileURL, let root = webRoot else { return false }
        return url.standardizedFileURL.path.hasPrefix(root.standardizedFileURL.path + "/")
    }
    func reply(_ id: String, _ value: [String: Any]) {
        let safeValue: [String: Any] = JSONSerialization.isValidJSONObject(value) ? value : ["ok": false, "error": "响应数据格式无效，原记录已保留。"]
        guard let json = try? JSONSerialization.data(withJSONObject: ["id": id, "value": safeValue]),
              let encoded = String(data: json, encoding: .utf8) else { return }
        web?.evaluateJavaScript("{const r=\(encoded);window.StudyNative?.receive(r.id,r.value);}", completionHandler: nil)
    }
    func summarize(_ events: [[String: Any]]) {
        StudyFocus.saveSummary(["day": StudyFocus.day(), "total": 0, "remaining": 0, "complete": false])
        let day = StudyFocus.day()
        let rows = events.filter { $0["kind"] as? String == "plan" && $0["day"] as? String == day }
        guard let baseRow = rows.last(where: { ($0["payload"] as? [String: Any])?["supplement"] as? Bool != true }),
              let base = baseRow["payload"] as? [String: Any] else { return }
        let plans = rows.filter { ($0["at"] as? String ?? "") >= (baseRow["at"] as? String ?? "") }.compactMap { $0["payload"] as? [String: Any] }
        let extra = plans.filter { $0["supplement"] as? Bool == true }.flatMap { $0["new"] as? [String] ?? [] }
        let words = Set((base["review"] as? [String] ?? []) + (base["new"] as? [String] ?? []) + extra)
        var flags: [String: Bool] = [:]
        for e in events where e["kind"] as? String == "settings" {
            for (id, value) in (e["payload"] as? [String: Any])?["wordFlags"] as? [String: Bool] ?? [:] { flags[id] = value }
        }
        var latest: [String: Bool] = [:]
        for e in events where e["kind"] as? String == "review" && e["day"] as? String == day {
            if e["purpose"] as? String == "practice" { continue }
            if let word = e["word"] as? String, words.contains(word), let rating = e["rating"] as? Int, (1...4).contains(rating) {
                let card = e["cardAfter"] as? [String: Any]
                latest[word] = rating >= 3 && (card == nil || card?["state"] as? Int == 2)
            }
        }
        let remaining = words.filter { flags[$0] != true && latest[$0] != true }.count
        StudyFocus.saveSummary(["day": day, "total": words.count, "remaining": remaining, "complete": !words.isEmpty && remaining == 0])
        if !words.isEmpty && remaining == 0 {
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["LokiStudy-reminder-" + StudyStorage.deviceID + "-" + day])
        }
    }
    func accountDeleted(_ id: String) {
        guard UUID(uuidString: id) != nil else { return }
        let script = "for (const store of [localStorage,sessionStorage]) { for (const key of Object.keys(store)) { if (key.startsWith('le:\(id):')) store.removeItem(key); } }"
        if let web = web {
            web.evaluateJavaScript(script) { [weak self] _, _ in self?.accountChanged() }
        } else { accountChanged() }
    }
    func accountChanged() {
        StudyFocus.endExam()
        DeviceActivityCenter().stopMonitoring([StudyFocus.examActivity])
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
        center.removeAllDeliveredNotifications()
        if let events = try? StudyStorage.events() { summarize(events) }
        StudyFocus.refresh()
        web?.stopLoading(); web?.reload()
        Task {
            if let time = UserDefaults.standard.string(forKey: StudyAccounts.reminderKey),
               let account = try? StudyAccounts.shared.active() {
                _ = try? await invoke("reminder", ["time": time, "profileId": account.id])
            }
        }
    }
    func invoke(_ method: String, _ params: [String: Any]) async throws -> [String: Any] {
        if ["save", "reminder", "manageAccounts", "configureFocus", "focus"].contains(method) {
            try StudyAccounts.shared.requireActive(params["profileId"])
        }
        switch method {
        case "load":
            let account = try StudyAccounts.shared.active()
            let events = try StudyStorage.events(); summarize(events)
            return ["events": events, "deviceId": account.id, "profileId": account.id,
                    "profileName": account.name, "status": "学习进度仅保存在当前本机账号，不提供云同步。"]
        case "save":
            guard let events = params["events"] as? [[String: Any]] else { throw StudyError.message("缺少学习记录。") }
            let saved = try StudyStorage.save(events); summarize(saved); return ["events": saved]
        case "speak":
            throw StudyError.message("该内容的离线录音尚未收录。")
        case "manageAccounts":
            sheet = .accounts
            return ["presented": true]
        case "configureFocus": sheet = .focus; return ["presented": true]
        case "focus":
            if params["active"] as? Bool == false {
                StudyFocus.endExam(); DeviceActivityCenter().stopMonitoring([StudyFocus.examActivity]); return ["active": false]
            }
            guard AuthorizationCenter.shared.authorizationStatus == .approved,
                  StudyFocus.defaults?.bool(forKey: "examAllowed") == true else { throw StudyError.message("请在专注设置中授权，并开启做题时限制应用。") }
            let selection = StudyFocus.selection("examSelection")
            guard StudyFocus.hasSelection(selection) else { throw StudyError.message("请先选择做题时需要限制的应用。") }
            let minutes = params["minutes"] as? Int ?? 60
            guard (15...180).contains(minutes) else { throw StudyError.message("专注时间须为 15—180 分钟。") }
            let end = Date().addingTimeInterval(Double(minutes * 60))
            let c = Calendar.current, parts: Set<Calendar.Component> = [.year, .month, .day, .hour, .minute, .second]
            let schedule = DeviceActivitySchedule(intervalStart: c.dateComponents(parts, from: Date()), intervalEnd: c.dateComponents(parts, from: end), repeats: false)
            try DeviceActivityCenter().startMonitoring(StudyFocus.examActivity, during: schedule)
            StudyFocus.defaults?.set(end, forKey: "examExpires"); StudyFocus.shield(StudyFocus.exam, selection)
            return ["active": true, "expires": end.timeIntervalSince1970]
        case "reminder":
            guard let time = params["time"] as? String else { throw StudyError.message("缺少提醒时间。") }
            let parts = time.split(separator: ":").compactMap { Int($0) }
            guard parts.count == 2, (0...23).contains(parts[0]), (0...59).contains(parts[1]) else { throw StudyError.message("提醒时间格式错误。") }
            let center = UNUserNotificationCenter.current()
            guard try await center.requestAuthorization(options: [.alert, .sound]) else { throw StudyError.message("系统通知未授权，学习计划已保存。") }
            let old = await center.pendingNotificationRequests().filter { $0.identifier.hasPrefix("LokiStudy-reminder-") }.map(\.identifier)
            try StudyAccounts.shared.requireActive(params["profileId"])
            center.removePendingNotificationRequests(withIdentifiers: old)
            let cal = StudyFocus.calendar
            for offset in 0..<14 {
                guard let day = cal.date(byAdding: .day, value: offset, to: Date()),
                      let date = cal.date(bySettingHour: parts[0], minute: parts[1], second: 0, of: day), date > Date() else { continue }
                let key = StudyFocus.day(date)
                if StudyFocus.defaults?.string(forKey: "completedDay") == key { continue }
                let content = UNMutableNotificationContent()
                content.title = "LE · 该背词了"
                content.body = "今天的学习任务已准备好，打开 LE 单词继续学习。"
                content.sound = .default
                let components = cal.dateComponents([.timeZone, .year, .month, .day, .hour, .minute], from: date)
                let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
                try StudyAccounts.shared.requireActive(params["profileId"])
                let notificationID = "LokiStudy-reminder-" + StudyStorage.deviceID + "-" + key
                try await center.add(.init(identifier: notificationID, content: content, trigger: trigger))
                do { try StudyAccounts.shared.requireActive(params["profileId"]) }
                catch { center.removePendingNotificationRequests(withIdentifiers: [notificationID]); throw error }
            }
            UserDefaults.standard.set(time, forKey: StudyAccounts.reminderKey)
            return ["scheduled": true, "days": 14]
        default: throw StudyError.message("此版本暂不支持这项原生操作。")
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if navigationAction.navigationType == .linkActivated, url.scheme == "https", url.host == "tatoeba.org" {
            UIApplication.shared.open(url); decisionHandler(.cancel); return
        }
        if navigationAction.shouldPerformDownload && url.scheme == "blob" { decisionHandler(.download); return }
        decisionHandler(isLocal(url) || url.absoluteString == "about:blank" ? .allow : .cancel)
    }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "-LokiStudy.json")
        exportFile = file; completionHandler(file)
    }
    func downloadDidFinish(_ download: WKDownload) {
        guard let file = exportFile, let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              var controller = scene.windows.first(where: \.isKeyWindow)?.rootViewController else { return }
        while let next = controller.presentedViewController { controller = next }
        let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
        share.popoverPresentationController?.sourceView = controller.view
        controller.present(share, animated: true)
    }
}

struct StudyWebView: UIViewRepresentable {
    @ObservedObject var bridge: StudyBridge
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.userContentController.add(bridge, name: "study")
        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsInlineMediaPlayback = true
        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = bridge; bridge.web = web
        web.isOpaque = false; web.backgroundColor = UIColor(red: 0.047, green: 0.082, blue: 0.071, alpha: 1)
        if let folder = Bundle.main.url(forResource: "web", withExtension: nil) {
            web.loadFileURL(folder.appendingPathComponent("index.html"), allowingReadAccessTo: folder)
        }
        return web
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct StudyFocusView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var social = StudyFocus.selection("socialSelection")
    @State private var exam = StudyFocus.selection("examSelection")
    @State private var dailyEnabled = StudyFocus.defaults?.bool(forKey: "dailyEnabled") ?? false
    @State private var examAllowed = StudyFocus.defaults?.bool(forKey: "examAllowed") ?? false
    @State private var socialPicker = false
    @State private var examPicker = false
    @State private var message = ""
    var body: some View {
        NavigationStack {
            Form {
                Section("选择限制范围") {
                    Button("授权屏幕使用时间") { Task { do { try await AuthorizationCenter.shared.requestAuthorization(for: .individual); message = "授权已完成，请选择应用。" } catch { message = error.localizedDescription } } }
                    Button("选择娱乐、社交应用") { socialPicker = true }
                    Text("已选 \(social.applicationTokens.count) 个应用、\(social.categoryTokens.count) 个类别、\(social.webDomainTokens.count) 个网站")
                    Toggle("未完成今日单词时限制社媒", isOn: $dailyEnabled)
                    Button("选择做题时限制的应用") { examPicker = true }
                    Text("已选 \(exam.applicationTokens.count) 个应用、\(exam.categoryTokens.count) 个类别、\(exam.webDomainTokens.count) 个网站")
                    Toggle("做题时允许应用限制", isOn: $examAllowed)
                    Text("请保留 LE 单词、电话及必要工具。此设置只影响你选定的范围，不能屏蔽所有系统功能。")
                    Button("保存专注设置") { save() }
                }
                Section("应急") {
                    Button("立即解除本次限制", role: .destructive) {
                        StudyFocus.emergencyRelease(); message = "已解除本次做题限制，今天的背词屏蔽暂停至明天。其他软件设置的限制不受影响。"
                    }
                    Text("可随时关闭上述开关或撤销系统授权。学习进度与应急解除分别记录。")
                }
                if !message.isEmpty { Text(message) }
            }.navigationTitle("学习专注").toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
                .familyActivityPicker(isPresented: $socialPicker, selection: $social)
                .familyActivityPicker(isPresented: $examPicker, selection: $exam)
        }
    }
    func save() {
        do {
            guard let state = StudyFocus.defaults else { throw StudyError.message("此构建尚未完成 App Group 签名。") }
            if dailyEnabled || examAllowed {
                guard AuthorizationCenter.shared.authorizationStatus == .approved else { throw StudyError.message("请先授权屏幕使用时间。") }
            }
            if dailyEnabled && !StudyFocus.hasSelection(social) { throw StudyError.message("请先选择娱乐、社交应用。") }
            if examAllowed && !StudyFocus.hasSelection(exam) { throw StudyError.message("请先选择做题限制范围。") }
            if dailyEnabled {
                let zone = TimeZone(identifier: "Asia/Shanghai")!
                try DeviceActivityCenter().startMonitoring(StudyFocus.dailyActivity,
                    during: DeviceActivitySchedule(intervalStart: DateComponents(timeZone: zone, hour: 0, minute: 0),
                                                   intervalEnd: DateComponents(timeZone: zone, hour: 23, minute: 59), repeats: true))
            } else { DeviceActivityCenter().stopMonitoring([StudyFocus.dailyActivity]); StudyFocus.daily.clearAllSettings() }
            StudyFocus.setSelection(social, key: "socialSelection"); StudyFocus.setSelection(exam, key: "examSelection")
            state.set(dailyEnabled, forKey: "dailyEnabled"); state.set(examAllowed, forKey: "examAllowed")
            if !examAllowed { StudyFocus.endExam(); DeviceActivityCenter().stopMonitoring([StudyFocus.examActivity]) }
            StudyFocus.refresh(); message = "设置已保存。完成今日任务后只解除本软件的背词限制。"
        } catch { message = error.localizedDescription }
    }
}
