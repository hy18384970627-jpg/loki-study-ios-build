import Foundation

// Stateless geometry: folding/resizing never reloads the web view or learning data.
enum StudyPaneLayout {
    static func pane(in bounds: CGRect, divisions: [CGRect]) -> CGRect {
        var panes = [bounds]
        for division in divisions {
            guard !division.isNull, !division.isEmpty,
                  division.origin.x.isFinite, division.origin.y.isFinite,
                  division.width.isFinite, division.height.isFinite else { continue }
            var next: [CGRect] = []
            for pane in panes {
                let cut = pane.intersection(division)
                if cut.isNull || cut.isEmpty { next.append(pane); continue }
                if division.height >= division.width {
                    if cut.minX > pane.minX { next.append(CGRect(x: pane.minX, y: pane.minY, width: cut.minX-pane.minX, height: pane.height)) }
                    if cut.maxX < pane.maxX { next.append(CGRect(x: cut.maxX, y: pane.minY, width: pane.maxX-cut.maxX, height: pane.height)) }
                } else {
                    if cut.minY > pane.minY { next.append(CGRect(x: pane.minX, y: pane.minY, width: pane.width, height: cut.minY-pane.minY)) }
                    if cut.maxY < pane.maxY { next.append(CGRect(x: pane.minX, y: cut.maxY, width: pane.width, height: pane.maxY-cut.maxY)) }
                }
            }
            if !next.isEmpty { panes = next }
        }
        var best = panes[0]
        for pane in panes.dropFirst() where pane.width*pane.height > best.width*best.height { best = pane }
        return best
    }
}
