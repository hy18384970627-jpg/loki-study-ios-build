import Foundation
import Security
import CryptoKit

enum StudyError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(value) = self { return value }; return nil }
}

enum StudyStorage {
    static func folder() throws -> URL {
        let base = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        var folder = try StudyAccounts.shared.activeFolder()
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: [.protectionKey: FileProtectionType.complete])
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try folder.setResourceValues(values)
        return folder
    }
    static var deviceID: String { (try? StudyAccounts.shared.active().id) ?? "unavailable" }
    static func events() throws -> [[String: Any]] {
        let file = try folder().appendingPathComponent("events.json")
        guard FileManager.default.fileExists(atPath: file.path) else { return [] }
        let data = try Data(contentsOf: file)
        guard let events = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw StudyError.message("学习记录格式异常，原文件已保留。") }
        try validate(events)
        return events
    }
    static func validate(_ events: [[String: Any]]) throws {
        guard JSONSerialization.isValidJSONObject(events) else {
            throw StudyError.message("学习记录包含不支持的类型，原记录已保留，请更新客户端后重试。")
        }
        guard events.count <= 100_000 else { throw StudyError.message("记录数量超过本次同步上限。") }
        var identifiers = Set<String>()
        let iso = ISO8601DateFormatter(); iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let plainISO = ISO8601DateFormatter()
        for e in events {
            guard let id = e["id"] as? String, id.count <= 100, !id.isEmpty,
                  let kind = e["kind"] as? String, ["review", "settings", "plan", "listen", "test"].contains(kind),
                  let at = e["at"] as? String, !at.isEmpty, at.count <= 40,
                  iso.date(from: at) != nil || plainISO.date(from: at) != nil,
                  identifiers.insert(id).inserted else { throw StudyError.message("发现无效或重复学习记录，未覆盖原数据。") }
        }
    }
    static func save(_ incoming: [[String: Any]]) throws -> [[String: Any]] {
        try validate(incoming)
        let original = try folder().appendingPathComponent("events.json")
        let backup = try folder().appendingPathComponent("events.before-scheduler-v2.json")
        if FileManager.default.fileExists(atPath: original.path), !FileManager.default.fileExists(atPath: backup.path) {
            try FileManager.default.copyItem(at: original, to: backup)
        }
        // Preserve records if another native save/sync has already added them.
        var merged = Dictionary(uniqueKeysWithValues: try events().map { ($0["id"] as! String, $0) })
        for e in incoming {
            let id = e["id"] as! String
            if let previous = merged[id], !NSDictionary(dictionary: previous).isEqual(to: e) {
                throw StudyError.message("学习记录冲突，原数据已保留。")
            }
            merged[id] = e
        }
        let result = merged.values.sorted {
            let a = ($0["at"] as? String ?? "", $0["id"] as? String ?? "")
            let b = ($1["at"] as? String ?? "", $1["id"] as? String ?? "")
            return a < b
        }
        let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        guard data.count <= 24 * 1024 * 1024 else { throw StudyError.message("学习记录过大，未覆盖原数据。") }
        try data.write(to: folder().appendingPathComponent("events.json"), options: [.atomic, .completeFileProtection])
        return result
    }
    static func cacheFile(_ text: String) throws -> URL {
        let folder = try folder().appendingPathComponent("audio", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: [.protectionKey: FileProtectionType.complete])
        let hash = SHA256.hash(data: Data(text.utf8)).map { String(format: "%02x", $0) }.joined()
        return folder.appendingPathComponent(hash + ".wav")
    }
    static func cache(_ data: Data, text: String) throws {
        let file = try cacheFile(text)
        try data.write(to: file, options: [.atomic, .completeFileProtection])
        let root = file.deletingLastPathComponent()
        let files = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.fileSizeKey, .contentModificationDateKey])
            .filter { $0.pathExtension == "wav" }
        let records = files.compactMap { url -> (URL, Int, Date)? in
            guard let values = try? url.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey]) else { return nil }
            return (url, values.fileSize ?? 0, values.contentModificationDate ?? .distantPast)
        }.sorted { $0.2 < $1.2 }
        var total = records.reduce(0) { $0 + $1.1 }
        for r in records where total > 128 * 1024 * 1024 && r.0 != file { try FileManager.default.removeItem(at: r.0); total -= r.1 }
    }
}

