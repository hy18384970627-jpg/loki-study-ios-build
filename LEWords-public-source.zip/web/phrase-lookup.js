(()=>{
 'use strict';
 let enabled=false,startedIn=null,suppressClick=false,requestNumber=0;
 const normal=text=>text.toLowerCase().replaceAll('’',"'").replace(/\s+/g,' ').trim();
 const element=node=>node?.nodeType===Node.ELEMENT_NODE?node:node?.parentElement;
 const container=node=>element(node)?.closest('#example-text,#lookup-example-text,#transcript p');
 let dialog,title,content;
 function paragraph(text,className){
   const node=document.createElement('p');
   node.textContent=text.replaceAll('\\n','\n');
   if(className)node.className=className;
   return node;
 }
 function section(heading){
   const node=document.createElement('section'),label=document.createElement('h3');
   label.textContent=heading;node.append(label);content.append(node);
   return node;
 }
 function close(){
   requestNumber++;
   dialog.close();
   window.getSelection()?.removeAllRanges();
 }
 async function show(text){
   const number=++requestNumber,key=normal(text);
   title.textContent=text;
   content.replaceChildren(paragraph('正在查本机短语词典…','muted'));
   if(!dialog.open)dialog.showModal();
   try{
     const reply=await window.pywebview.api.call('phraseLookup',{text:key});
     if(number!==requestNumber||!dialog.open)return;
     if(!reply.ok)throw Error(reply.error||'短语查询未完成');
     const entry=reply.result,prepared=window.LOKI_STUDY_AUDIO||{};
     content.replaceChildren();
     content.append(paragraph(entry.meaning||'本机暂未收录整条短语的释义，可参考下面的组成词和相关搭配。','phrase-meaning'));
     if(entry.definition)section('英文释义').append(paragraph(entry.definition));
     const words=window.LOKI_WORDS||[],glossary=prepared.glossary||{};
     const tokens=[...new Set(key.split(' '))];
     const indexed=new Map(words.map(word=>[word.id,word]));
     const components=tokens.map(token=>({token,entry:glossary[token]||indexed.get(token)})).filter(item=>item.entry?.meaning);
     if(components.length){
       const block=section('组成词');
       for(const item of components)block.append(paragraph(item.token+' · '+item.entry.meaning));
     }
     const stop=new Set('a an the of to in on at for by with from as and or be is are was were been being this that it its have has had'.split(' '));
     const useful=tokens.filter(token=>!stop.has(token));
     const related=words.filter(word=>word.id.includes(' ')&&word.id!==key&&useful.some(token=>word.id.split(' ').includes(token)))
       .sort((a,b)=>tokens.filter(token=>b.id.split(' ').includes(token)).length-tokens.filter(token=>a.id.split(' ').includes(token)).length)
       .slice(0,4);
     if(related.length){
       const block=section('相关搭配');
       for(const word of related)block.append(paragraph(word.word+' · '+word.meaning));
     }
     const matches=Object.entries(prepared.examples||{}).filter(([,sentence])=>
       (' '+normal(sentence).replace(/[^a-z'\- ]/g,' ')+' ').includes(' '+key+' ')).slice(0,2);
     if(matches.length){
       const block=section('例句');
       for(const [id,sentence] of matches){
         block.append(paragraph(sentence,'phrase-english'));
         if(prepared.exampleTranslations?.[id])block.append(paragraph(prepared.exampleTranslations[id],'muted'));
       }
     }
   }catch(error){
     if(number===requestNumber&&dialog.open)content.replaceChildren(paragraph(error.message));
   }
 }
 function enable(){
   if(enabled||!window.pywebview?.api)return;
   enabled=true;
   document.body.classList.add('desktop-phrase-selection');
   dialog=document.createElement('dialog');dialog.id='phrase-gloss';
   dialog.setAttribute('aria-labelledby','phrase-title');
   const header=document.createElement('div');header.className='gloss-head';
   title=document.createElement('strong');title.id='phrase-title';title.lang='en';
   const button=document.createElement('button');button.textContent='×';button.setAttribute('aria-label','关闭短语释义');button.onclick=close;
   header.append(title,button);content=document.createElement('div');dialog.append(header,content);document.body.append(dialog);
   dialog.addEventListener('click',event=>{if(event.target===dialog)close();});
   dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
   document.addEventListener('pointerdown',event=>{
     if(event.button===0){startedIn=container(event.target);suppressClick=false;}
   },true);
   document.addEventListener('pointerup',event=>{
     if(event.button!==0||!startedIn)return;
     const selection=window.getSelection();
     const origin=startedIn;startedIn=null;
     if(!selection||selection.isCollapsed||container(selection.anchorNode)!==origin||container(selection.focusNode)!==origin)return;
     const text=selection.toString().replace(/^[^A-Za-z]+|[^A-Za-z]+$/g,'').trim();
     if(!/^[A-Za-z][A-Za-z’'\-\s]*$/.test(text)||text.length>140||text.split(/\s+/).length<2||text.split(/\s+/).length>12)return;
     suppressClick=true;
     setTimeout(()=>show(text),0);
   },true);
   document.addEventListener('click',event=>{
     if(suppressClick&&container(event.target)){event.preventDefault();event.stopImmediatePropagation();suppressClick=false;}
   },true);
 }
 window.addEventListener('pywebviewready',enable);
 enable();
})();
