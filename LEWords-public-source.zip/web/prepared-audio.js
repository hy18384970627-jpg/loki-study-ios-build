window.LOKI_STUDY_AUDIO={words:[],examples:{},exampleTranslations:{},wordRecordings:{},exampleRecordings:{},exampleVariants:{},glossary:{},listening:[]};
