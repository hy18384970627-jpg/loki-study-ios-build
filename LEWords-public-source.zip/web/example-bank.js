(function(root){
 'use strict';
 function choices(prepared,id){
   const variants=(prepared.exampleVariants?.[id]||[]).filter(row=>row&&typeof row.id==='string'&&row.en&&row.zh);
   const old=prepared.examples?.[id];
   if(old&&!variants.some(row=>row.recording)&&!variants.some(row=>row.en===old)){
     variants.push({id:'original',type:'原例句',en:old,zh:prepared.exampleTranslations?.[id]||'',recording:prepared.exampleRecordings?.[id]||''});
   }
   return variants;
 }
 function choose(rows,last,random=Math.random){
   const recorded=rows.filter(row=>row.recording);
   const varied=recorded.filter(row=>row.id!=='original');
   const available=varied.length?varied:recorded.length?recorded:rows;
   const different=available.filter(row=>row.id!==last);
   const pool=different.length?different:available;
   return pool.length?pool[Math.min(pool.length-1,Math.floor(random()*pool.length))]:null;
 }
 const api={choices,choose};
 if(typeof module!=='undefined')module.exports=api;
 else root.ExampleBank=api;
})(typeof window!=='undefined'?window:globalThis);
