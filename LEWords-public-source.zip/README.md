LE Words: iPhone-only, local learning accounts, no cloud sync or Loki pairing. This compile-only archive contains no private recordings, personal examples or study histories.
