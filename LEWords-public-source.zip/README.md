LE Words: Local learning profiles, without cloud sync or Loki pairing. This compile-only archive contains no private recordings, personal examples or study histories.
