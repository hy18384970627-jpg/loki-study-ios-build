#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
stage="${LE_STAGE:-staged/v2}"
script_root="$PWD"
cd "$stage/ios"
mkdir -p Tests/UI build
if [ -f ../tests/ui/ReleaseUITests.swift ]; then
  cp ../tests/ui/ReleaseUITests.swift Tests/UI/
else
  cp "$script_root/tests/ui/ReleaseUITests.swift" Tests/UI/
fi
python3 - <<'PY'
from pathlib import Path
p=Path('project.yml')
s=p.read_text()
target='''  ReleaseUITests:
    type: bundle.ui-testing
    platform: iOS
    sources: [Tests/UI]
    settings:
      base:
        PRODUCT_BUNDLE_IDENTIFIER: dev.zcydrkv7yh.lewords.release-uitests
        GENERATE_INFOPLIST_FILE: YES
        TEST_TARGET_NAME: LokiStudy
    dependencies:
      - target: LokiStudy
'''
s=s.replace('schemes:\n',target+'schemes:\n')
s+='''    test:
      config: Debug
      targets: [ReleaseUITests]
'''
p.write_text(s)
PY
xcodegen generate --spec project.yml
sim_id=$(python3 - <<'PY'
import json,subprocess
d=json.loads(subprocess.check_output(['xcrun','simctl','list','devices','available','-j']))
phones=[v for k,items in d['devices'].items() if 'iOS-26' in k for v in items if v['name'].startswith('iPhone')]
assert phones,'No iOS 26 iPhone simulator available'
print(phones[0]['udid'])
PY
)
xcrun simctl boot "$sim_id" || true
xcrun simctl bootstatus "$sim_id" -b
xcodebuild -project LokiStudy.xcodeproj -scheme LokiStudy -configuration Debug \
  -destination "platform=iOS Simulator,id=$sim_id" -derivedDataPath build/UITestDerived \
  -resultBundlePath build/NativeSmoke.xcresult CODE_SIGNING_ALLOWED=NO \
  -parallel-testing-enabled NO test > build/native-ui.log 2>&1 || {
    tail -100 build/native-ui.log
    ditto -c -k --keepParent build/NativeSmoke.xcresult build/native-ui-results.zip || true
    exit 1
  }
ditto -c -k --keepParent build/NativeSmoke.xcresult build/native-ui-results.zip
xcrun xcresulttool export attachments --path build/NativeSmoke.xcresult --output-path build/native-screenshots
echo 'Native simulator lifecycle passed. Screenshots are runtime QA evidence, not final App Store media.'
