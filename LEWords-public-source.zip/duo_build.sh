#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
LE_STAGE=. bash release_build.sh
cd ios
swiftc Sources/App/StudyPaneLayout.swift ../tests/duo/main.swift -o build/duo-geometry
build/duo-geometry | tee build/duo-geometry.log
xcodebuild -version > build/duo-environment.log
xcodebuild -showsdks >> build/duo-environment.log
xcrun simctl help >> build/duo-environment.log
xcrun simctl io help >> build/duo-environment.log 2>&1 || true
xcrun simctl list devices available -j > build/duo-devices.json
python3 - <<'PY'
from pathlib import Path
import json
p=Path('project.yml');s=p.read_text()
target="""  DuoUITests:
    type: bundle.ui-testing
    platform: iOS
    sources: [Tests/Duo]
    settings:
      base:
        PRODUCT_BUNDLE_IDENTIFIER: dev.zcydrkv7yh.lewords.duo-uitests
        GENERATE_INFOPLIST_FILE: YES
        TEST_TARGET_NAME: LokiStudy
    dependencies:
      - target: LokiStudy
"""
s=s.replace('schemes:\n',target+'schemes:\n')
s+='    test:\n      config: Debug\n      targets: [DuoUITests]\n'
p.write_text(s)
d=json.loads(Path('build/duo-devices.json').read_text())
devices=[v for k,items in d['devices'].items() if 'iOS-27-1' in k for v in items if 'Duo' in v['name']]
assert devices, 'No actual iPhone Duo iOS27.1 simulator: do not substitute another device'
Path('build/duo-device-id.txt').write_text(devices[0]['udid'])
PY
mkdir -p Tests/Duo
cp ../tests/duo/DuoUITests.swift Tests/Duo/
xcodegen generate --spec project.yml
sim_id=$(cat build/duo-device-id.txt)
xcrun simctl boot "$sim_id" || true
open -a Simulator
python3 - "$sim_id" <<'PY'
import subprocess,sys
with open('build/duo-boot.log','w') as log:
    subprocess.run(['xcrun','simctl','bootstatus',sys.argv[1],'-b'],check=True,timeout=600,stdout=log,stderr=subprocess.STDOUT)
PY
xcrun simctl io "$sim_id" enumerate >> build/duo-environment.log
xcodebuild -project LokiStudy.xcodeproj -scheme LokiStudy -configuration Debug \
 -destination "platform=iOS Simulator,id=$sim_id" -derivedDataPath build/DuoDerived \
 -resultBundlePath build/Duo.xcresult CODE_SIGNING_ALLOWED=NO \
 -only-testing:DuoUITests/DuoUITests/testDuoViewsAndRotation \
 -parallel-testing-enabled NO test > build/duo-uitests.log 2>&1 || { tail -80 build/duo-uitests.log; exit 1; }
mkdir -p build/native-screenshots/duo
xcrun xcresulttool export attachments --path build/Duo.xcresult --output-path build/native-screenshots/duo
xcrun simctl shutdown "$sim_id"
ditto -c -k --keepParent build/native-screenshots build/duo-screenshots.zip
