import Foundation
import Security
import CryptoKit

enum StudyError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(value) = self { return value }; return nil }
}

enum StudyStorage {
    static func folder() throws -> URL {
        let base = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        var folder = base.appendingPathComponent("LokiStudy", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: [.protectionKey: FileProtectionType.complete])
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try folder.setResourceValues(values)
        return folder
    }
    static var deviceID: String {
        if let id = UserDefaults.standard.string(forKey: "studyDeviceID") { return id }
        let id = UUID().uuidString; UserDefaults.standard.set(id, forKey: "studyDeviceID"); return id
    }
    static func events() throws -> [[String: Any]] {
        let file = try folder().appendingPathComponent("events.json")
        guard FileManager.default.fileExists(atPath: file.path) else { return [] }
        let data = try Data(contentsOf: file)
        guard let events = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { throw StudyError.message("学习记录格式异常，原文件已保留。") }
        try validate(events)
        return events
    }
    static func validate(_ events: [[String: Any]]) throws {
        guard events.count <= 100_000 else { throw StudyError.message("记录数量超过本次同步上限。") }
        var identifiers = Set<String>()
        let iso = ISO8601DateFormatter(); iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let plainISO = ISO8601DateFormatter()
        for e in events {
            guard let id = e["id"] as? String, id.count <= 100, !id.isEmpty,
                  let kind = e["kind"] as? String, ["review", "settings", "plan", "listen", "test"].contains(kind),
                  let at = e["at"] as? String, !at.isEmpty, at.count <= 40,
                  iso.date(from: at) != nil || plainISO.date(from: at) != nil,
                  identifiers.insert(id).inserted else { throw StudyError.message("发现无效或重复学习记录，未覆盖原数据。") }
        }
    }
    static func save(_ incoming: [[String: Any]]) throws -> [[String: Any]] {
        try validate(incoming)
        // Preserve records if another native save/sync has already added them.
        var merged = Dictionary(uniqueKeysWithValues: try events().map { ($0["id"] as! String, $0) })
        for e in incoming {
            let id = e["id"] as! String
            if let previous = merged[id], !NSDictionary(dictionary: previous).isEqual(to: e) {
                throw StudyError.message("学习记录冲突，原数据已保留。")
            }
            merged[id] = e
        }
        let result = merged.values.sorted {
            let a = ($0["at"] as? String ?? "", $0["id"] as? String ?? "")
            let b = ($1["at"] as? String ?? "", $1["id"] as? String ?? "")
            return a < b
        }
        let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        guard data.count <= 24 * 1024 * 1024 else { throw StudyError.message("学习记录过大，未覆盖原数据。") }
        try data.write(to: folder().appendingPathComponent("events.json"), options: [.atomic, .completeFileProtection])
        return result
    }
    static func cacheFile(_ text: String) throws -> URL {
        let folder = try folder().appendingPathComponent("audio", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: [.protectionKey: FileProtectionType.complete])
        let hash = SHA256.hash(data: Data(text.utf8)).map { String(format: "%02x", $0) }.joined()
        return folder.appendingPathComponent(hash + ".wav")
    }
    static func cache(_ data: Data, text: String) throws {
        let file = try cacheFile(text)
        try data.write(to: file, options: [.atomic, .completeFileProtection])
        let root = file.deletingLastPathComponent()
        let files = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.fileSizeKey, .contentModificationDateKey])
            .filter { $0.pathExtension == "wav" }
        let records = files.compactMap { url -> (URL, Int, Date)? in
            guard let values = try? url.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey]) else { return nil }
            return (url, values.fileSize ?? 0, values.contentModificationDate ?? .distantPast)
        }.sorted { $0.2 < $1.2 }
        var total = records.reduce(0) { $0 + $1.1 }
        for r in records where total > 128 * 1024 * 1024 && r.0 != file { try FileManager.default.removeItem(at: r.0); total -= r.1 }
    }
}

enum StudyToken {
    private static var query: [String: Any] { [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "dev.zcydrkv7yh.lokistudy.gateway", kSecAttrAccount as String: "gateway"] }
    static func read() -> String {
        var q = query; q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var value: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &value) == errSecSuccess, let data = value as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func save(_ value: String) throws {
        if value.isEmpty { SecItemDelete(query as CFDictionary); return }
        let data = Data(value.utf8)
        let updated = SecItemUpdate(query as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if updated == errSecSuccess { return }
        guard updated == errSecItemNotFound else { throw StudyError.message("钥匙串保存失败。") }
        var q = query; q[kSecValueData as String] = data
        q[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        guard SecItemAdd(q as CFDictionary, nil) == errSecSuccess else { throw StudyError.message("钥匙串保存失败。") }
    }
}

final class StudyNoRedirect: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

enum StudyNetwork {
    static let session = URLSession(configuration: .ephemeral, delegate: StudyNoRedirect(), delegateQueue: nil)
    static func request(_ path: String, body: [String: Any]) async throws -> Data {
        let endpoint = UserDefaults.standard.string(forKey: "studyEndpoint") ?? ""
        guard let c = URLComponents(string: endpoint), c.scheme == "https", c.host != nil, c.user == nil, c.password == nil,
              c.query == nil, c.fragment == nil, c.path.isEmpty || c.path == "/", StudyToken.read().count >= 32,
              let url = URL(string: endpoint.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + path) else {
            throw StudyError.message("请先连接现有 Loki 的私人 HTTPS 入口。")
        }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 210)
        request.httpMethod = "POST"; request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer " + StudyToken.read(), forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            if status == 404 && path == "/v1/study/sync" { throw StudyError.message("学习同步接口尚未启用，本机记录已保留。") }
            if status == 409 || status == 429 { throw StudyError.message("Loki 正在处理其他声音任务，稍后重试。") }
            throw StudyError.message("连接未完成（HTTP \(status)），请核对私人入口和配对设置。")
        }
        guard data.count <= 24 * 1024 * 1024 else { throw StudyError.message("本次返回数据过大。") }
        return data
    }
    static func wave(_ pcm: Data) throws -> Data {
        guard !pcm.isEmpty, pcm.count.isMultiple(of: 2), pcm.count <= 24_000 * 2 * 120 else { throw StudyError.message("语音数据为空、不完整或过长。") }
        var out = Data()
        func u16(_ v: UInt16) { var x = v.littleEndian; withUnsafeBytes(of: &x) { out.append(contentsOf: $0) } }
        func u32(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { out.append(contentsOf: $0) } }
        out.append(contentsOf: "RIFF".utf8); u32(UInt32(pcm.count + 36)); out.append(contentsOf: "WAVEfmt ".utf8)
        u32(16); u16(1); u16(1); u32(24_000); u32(48_000); u16(2); u16(16)
        out.append(contentsOf: "data".utf8); u32(UInt32(pcm.count)); out.append(pcm); return out
    }
}
