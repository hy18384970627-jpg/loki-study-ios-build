(function(root){
  'use strict';
  const lib = typeof module !== 'undefined' ? require('./vendor/fsrs.js') : root.FSRS;
  const MINUTE=60000, DAY=86400000;
  function dayKey(date=new Date()) {
    return new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
  }
  function endDay(day) {return new Date(day+'T23:59:59+08:00');}
  function stable(value){return JSON.stringify(value,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);}
  function merge(a,b){
    const map=new Map();
    for(const e of [...a,...b]) {
      if(!e || typeof e.id!=='string' || !Number.isFinite(Date.parse(e.at))) throw Error('无效的学习记录');
      if(map.has(e.id) && stable(map.get(e.id))!==stable(e)) throw Error('发现记录冲突，已保留原数据');
      map.set(e.id,e);
    }
    return [...map.values()].sort((a,b)=>a.at.localeCompare(b.at)||a.id.localeCompare(b.id));
  }
  function scheduler(retention=.9){return lib.fsrs({request_retention:retention,enable_fuzz:false});}
  function materialize(events, retention=.9){
    const cards={}, latest={}, f=scheduler(retention);
    for(const e of merge([],events)) if(e.kind==='review') {
      if(![1,2,3,4].includes(e.rating)||typeof e.word!=='string') continue;
      const now=new Date(e.at), card=cards[e.word]||lib.createEmptyCard(now);
      cards[e.word]=f.repeat(card,now)[e.rating].card;
      latest[e.word]=e;
    }
    return {cards,latest};
  }
  function settings(events){
    const last=events.filter(e=>e.kind==='settings').at(-1);
    return Object.assign({minutes:60,vocabMinutes:20,examDate:'',retention:.9,newLimit:20,reminder:'20:00'},last?.payload||{});
  }
  function newPlan(words,events,now=new Date()){
    const s=settings(events),day=dayKey(now),{cards}=materialize(events,s.retention);
    const due=Object.keys(cards).filter(id=>new Date(cards[id].due)<=endDay(day));
    due.sort((a,b)=>new Date(cards[a].due)-new Date(cards[b].due));
    // Start with useful intermediate vocabulary; keep basic words available for
    // lookup and later assessment rather than assuming they are all mastered.
    const remaining=words.filter(w=>!cards[w.id]).sort((a,b)=>{
      const priority=w=>w.rank>=1500&&w.rank<=15000?0:1;
      return priority(a)-priority(b);
    });
    const days=s.examDate?Math.floor((new Date(s.examDate+'T00:00:00+08:00')-now)/DAY)-14:null;
    const needed=days>0?Math.ceil(remaining.length/days):null;
    const timeCap=Math.max(0,Math.floor((s.vocabMinutes*60-due.length*10)/45));
    const count=Math.min(remaining.length,timeCap,s.newLimit,needed??s.newLimit);
    return {day,review:due,new:remaining.slice(0,count).map(w=>w.id),needed,timeCap,
      warning:days!==null&&days<=0?'已进入考前巩固期，建议核实考试日期和学习范围。':needed!==null&&needed>Math.min(timeCap,s.newLimit)?'按当前时间预算，考前无法覆盖全部未学词；请调整时间或优先范围。':''};
  }
  function todayPlan(words,events,now=new Date()){
    const day=dayKey(now),existing=events.find(e=>e.kind==='plan'&&e.day===day);
    return existing?.payload||newPlan(words,events,now);
  }
  function progress(plan,events){
    const ids=[...new Set([...plan.review,...plan.new])], latest={};
    for(const e of events)if(e.kind==='review'&&e.day===plan.day&&ids.includes(e.word))latest[e.word]=e;
    const done=ids.filter(id=>latest[id]?.rating>=3);
    return {total:ids.length,done:done.length,remaining:ids.filter(id=>!done.includes(id)),complete:ids.length>0&&done.length===ids.length};
  }
  function coverage(ranges,duration){
    if(!(duration>0))return 0;
    const list=ranges.filter(r=>Array.isArray(r)&&r.length===2&&r.every(Number.isFinite)).map(([a,b])=>[Math.max(0,a),Math.min(duration,b)]).filter(([a,b])=>b>a).sort((a,b)=>a[0]-b[0]);
    const merged=[];
    for(const [a,b] of list){const last=merged.at(-1);if(last&&a<=last[1])last[1]=Math.max(last[1],b);else merged.push([a,b]);}
    return Math.min(1,merged.reduce((n,[a,b])=>n+b-a,0)/duration);
  }
  const api={dayKey,merge,materialize,settings,newPlan,todayPlan,progress,coverage};
  if(typeof module!=='undefined')module.exports=api;else root.StudyCore=api;
})(typeof window!=='undefined'?window:globalThis);
