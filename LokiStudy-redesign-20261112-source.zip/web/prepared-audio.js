window.LOKI_STUDY_AUDIO = { words: [], examples: {} };
