(function(root){
 'use strict';
 const lib=typeof module!=='undefined'?require('./vendor/fsrs.js'):root.FSRS;
 const DAY=86400000,MODEL='FSRS-6',REVIEW=2;
 function dayKey(date=new Date()){return new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);}
 function endDay(day){return new Date(day+'T23:59:59+08:00');}
 function stable(v){return JSON.stringify(v,(_,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);}
 function merge(a,b){const m=new Map();for(const e of [...a,...b]){if(!e||typeof e.id!=='string'||!Number.isFinite(Date.parse(e.at)))throw Error('无效的学习记录');if(m.has(e.id)&&stable(m.get(e.id))!==stable(e))throw Error('发现记录冲突，已保留原数据');m.set(e.id,e);}return [...m.values()].sort((a,b)=>a.at.localeCompare(b.at)||a.id.localeCompare(b.id));}
 function validWeights(w){return Array.isArray(w)&&w.length===21&&w.every(Number.isFinite)&&w.slice(0,4).every(x=>x>0)&&w[20]>=.1&&w[20]<=.8;}
 function settings(events){
  const s={minutes:60,vocabMinutes:20,examDate:'',retention:.9,newLimit:20,dailyLimit:100,reviewLimit:0,loadMode:'total',deck:'ielts',order:'sequence',reminder:'20:00',wordFlags:{},bookmarks:{},personalization:null};
  let legacy=false,explicit=false;
  for(const e of events)if(e.kind==='settings'&&e.payload){const p=e.payload;legacy ||= Object.hasOwn(p,'newLimit');explicit ||= Object.hasOwn(p,'loadMode');const flags=s.wordFlags,marks=s.bookmarks;Object.assign(s,p);s.wordFlags={...flags,...p.wordFlags};s.bookmarks={...marks,...p.bookmarks};}
  if(legacy&&!explicit)s.loadMode='separate';
  if(!validWeights(s.personalization?.weights))s.personalization=null;
  return s;
 }
 function scheduler(retention=.9,weights){return lib.fsrs({request_retention:retention,enable_fuzz:false,...(validWeights(weights)?{w:weights}:{})});}
 function restore(c){return {...c,due:new Date(c.due),...(c.last_review?{last_review:new Date(c.last_review)}:{})};}
 function serialize(c){return {...c,due:c.due.toISOString(),...(c.last_review?{last_review:c.last_review.toISOString()}:{})};}
 function isReview(e){return e.kind==='review'&&e.purpose!=='practice'&&[1,2,3,4].includes(e.rating)&&typeof e.word==='string';}
 let memoEvents,memoState;
 function materialize(events){
  if(events===memoEvents)return memoState;
  const ordered=merge([],events),s=settings(ordered),cards=Object.create(null),scheduled=Object.create(null),latest=Object.create(null);
  const personal=scheduler(s.retention,s.personalization?.weights);let retention=.9;
  for(const e of ordered){
   if(e.kind==='settings'&&Number.isFinite(e.payload?.retention))retention=e.payload.retention;
   if(!isReview(e))continue;
   const now=new Date(e.at),f=scheduler(retention,e.scheduler?.weights),saved=e.cardAfter;
   scheduled[e.word]=saved&&Number.isFinite(Date.parse(saved.due))&&[0,1,2,3].includes(saved.state)?restore(saved):f.repeat(scheduled[e.word]||lib.createEmptyCard(now),now)[e.rating].card;
   cards[e.word]=personal.repeat(cards[e.word]||lib.createEmptyCard(now),now)[e.rating].card;
   latest[e.word]=e;
  }
  // Personal parameters rebuild memory only; promised due dates and steps are preserved.
  for(const [id,c]of Object.entries(cards))cards[id]={...scheduled[id],stability:c.stability,difficulty:c.difficulty};
  memoEvents=events;return memoState={cards,latest,settings:s};
 }
 function hash(s){let n=2166136261;for(const c of s)n=Math.imul(n^c.charCodeAt(0),16777619);return n>>>0;}
 function deckWords(words,s){let list=words.filter(w=>s.deck==='personal'?w.tags?.includes('我的生词'):s.deck==='all'||w.decks?.includes(s.deck)||(!w.decks&&s.deck==='ielts'));if(s.order==='random')return [...list].sort((a,b)=>hash(a.id)-hash(b.id));return list;}
 function unseen(words,cards,assigned=new Set()){return words.filter(w=>!cards[w.id]&&!assigned.has(w.id)).sort((a,b)=>(a.studyPriority??2)-(b.studyPriority??2));}
 function newPlan(words,events,now=new Date()){
  const s=settings(events),day=dayKey(now),{cards}=materialize(events),flags=s.wordFlags;
  const introduced=new Set(),touched=new Set(),seen=new Set();
  for(const e of merge([],events))if(isReview(e)){if(e.day===day){touched.add(e.word);if(!seen.has(e.word))introduced.add(e.word);}seen.add(e.word);}
  const due=Object.keys(cards).filter(id=>!flags[id]&&!introduced.has(id)&&(new Date(cards[id].due)<=endDay(day)||touched.has(id))).sort((a,b)=>new Date(cards[a].due)-new Date(cards[b].due));
  const mandatory=due.filter(id=>touched.has(id)||cards[id].state!==REVIEW);
  const cap=s.loadMode==='total'?Math.max(0,s.dailyLimit-introduced.size):s.reviewLimit||Infinity;
  const review=[...mandatory,...due.filter(id=>!mandatory.includes(id)).slice(0,Math.max(0,cap-mandatory.length))];
  const newCount=s.loadMode==='total'?Math.max(0,s.dailyLimit-review.length):s.newLimit;
  const available=unseen(deckWords(words,s),cards).filter(w=>!flags[w.id]);
  const added=available.slice(0,Math.max(0,newCount-introduced.size)).map(w=>w.id);
  const days=s.examDate?Math.ceil((new Date(s.examDate+'T23:59:59+08:00')-now)/DAY):null;
  return {day,revision:true,deck:s.deck,review,new:[...introduced,...added],backlog:due.filter(id=>!review.includes(id)).length,needed:days>0?Math.ceil(available.length/days):null,warning:review.length>cap?'已开始的复习会保留；新词已减少。':''};
 }
 function todayPlan(words,events,now=new Date()){
  const day=dayKey(now),all=events.filter(e=>e.kind==='plan'&&e.day===day&&!e.payload?.personalWord),baseEvent=all.filter(e=>!e.payload?.supplement).at(-1);
  if(!baseEvent)return newPlan(words,events,now);
  const base=baseEvent.payload,extras=all.filter(e=>e.payload?.supplement&&e.at>=baseEvent.at).flatMap(e=>e.payload.new||[]);
  return extras.length?{...base,new:[...new Set([...base.new,...extras])].filter(id=>!base.review.includes(id))}:base;
 }
 function additionalWords(words,events,plan,limit=20){const s=settings(events),room=s.loadMode==='total'?s.dailyLimit-plan.review.length-plan.new.length:s.newLimit-plan.new.length;return unseen(deckWords(words,s),materialize(events).cards,new Set([...plan.review,...plan.new])).filter(w=>!s.wordFlags[w.id]).slice(0,Math.max(0,Math.min(limit,room))).map(w=>w.id);}
 function progress(plan,events,now=new Date()){
  const ids=[...new Set([...plan.review,...plan.new])],{cards,latest,settings:s}=materialize(events);
  const done=new Set(ids.filter(id=>s.wordFlags[id]||(latest[id]?.day===plan.day&&cards[id]?.state===REVIEW&&latest[id].rating>=3)));
  const remaining=ids.filter(id=>!done.has(id)),ready=remaining.filter(id=>!cards[id]||new Date(cards[id].due)<=now||(cards[id].state===REVIEW&&new Date(cards[id].due)<=endDay(plan.day))),waiting=remaining.filter(id=>!ready.includes(id));
  const nextDue=waiting.length?new Date(Math.min(...waiting.map(id=>new Date(cards[id].due).getTime()))):null;
  return {total:ids.length,done:done.size,remaining,ready,waiting,nextDue,complete:!remaining.length&&ids.length>0};
 }
 function reviewResult(events,id,rating,now=new Date(),durationMs=0){
  const {cards,settings:s}=materialize(events),card=cards[id]||lib.createEmptyCard(now),r=scheduler(s.retention,s.personalization?.weights).repeat(card,now)[rating];
  return {word:id,rating,purpose:'scheduled',durationMs:Math.max(0,Math.min(300000,durationMs)),scheduler:{model:MODEL,retention:s.retention,weights:s.personalization?.weights||null,version:'loki-scheduler-2'},previousDue:card.due.toISOString(),cardAfter:serialize(r.card),revlog:r.log};
 }
 function stats(words,events,now=new Date()){
  const {cards,settings:s}=materialize(events),book=deckWords(words,s),days={},seen=new Set(),firstDay=new Map();
  for(const e of merge([],events))if(isReview(e)){
   const d=days[e.day]??={new:new Set(),review:new Set(),attempts:0,ms:0};
   if(!seen.has(e.word))firstDay.set(e.word,e.day);
   (firstDay.get(e.word)===e.day?d.new:d.review).add(e.word);d.attempts++;d.ms+=Math.max(0,Math.min(e.durationMs||0,300000));seen.add(e.word);
  }
  const forecast=Array.from({length:7},(_,i)=>{const day=dayKey(new Date(now.getTime()+i*DAY));return {day,count:Object.entries(cards).filter(([id,c])=>!s.wordFlags[id]&&(i===0?dayKey(c.due)<=day:dayKey(c.due)===day)).length};});
  const history=Array.from({length:28},(_,i)=>{const day=dayKey(new Date(now.getTime()-(27-i)*DAY)),d=days[day];return {day,new:d?.new.size||0,review:d?.review.size||0,attempts:d?.attempts||0,minutes:Math.round((d?.ms||0)/60000)};});
  return {total:book.length,learned:book.filter(w=>cards[w.id]).length,known:book.filter(w=>s.wordFlags[w.id]).length,unseen:book.filter(w=>!cards[w.id]&&!s.wordFlags[w.id]).length,history,forecast,globalLearned:Object.keys(cards).length};
 }
 function coverage(ranges,duration){if(!(duration>0))return 0;const list=ranges.filter(r=>Array.isArray(r)&&r.length===2&&r.every(Number.isFinite)).map(([a,b])=>[Math.max(0,a),Math.min(duration,b)]).filter(([a,b])=>b>a).sort((a,b)=>a[0]-b[0]);const m=[];for(const [a,b]of list){const p=m.at(-1);if(p&&a<=p[1])p[1]=Math.max(p[1],b);else m.push([a,b]);}return Math.min(1,m.reduce((n,[a,b])=>n+b-a,0)/duration);}
 const api={MODEL,dayKey,endDay,merge,materialize,settings,scheduler,validWeights,deckWords,newPlan,todayPlan,additionalWords,progress,reviewResult,stats,coverage};
 if(typeof module!=='undefined')module.exports=api;else root.StudyCore=api;
})(typeof window!=='undefined'?window:globalThis);

