const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const ctx={window:{}};vm.runInNewContext(fs.readFileSync(__dirname+'/../web/tests.js','utf8'),ctx);
const tests=ctx.window.LOKI_TESTS;assert.ok(tests.length>=1);
for(const test of tests){assert.equal(test.parts.length,4);const ids=new Set();let count=0;
 for(const part of test.parts){assert.equal(part.questions.length,10);assert.ok(part.script.length>1000);
  for(const q of part.questions){assert.ok(!ids.has(String(q.id)));ids.add(String(q.id));assert.ok(q.answers.length);assert.ok(q.prompt);count++;}
 }assert.equal(count,40);
 console.log(test.id+': 4 parts, 40 questions, unique IDs; '+test.parts.map(p=>p.script.split(/\s+/).length).reduce((a,b)=>a+b)+' script words');
}
