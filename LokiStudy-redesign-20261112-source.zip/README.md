Standalone Loki IELTS iPhone client build inputs.
No voice models, chat records, credentials, pairing files or runtime configuration are bundled.
ECDICT and ts-fsrs licenses are included in web/vendor.
Unsigned builds require separate owner-managed Apple development signing before installation.
