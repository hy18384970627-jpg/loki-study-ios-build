import Foundation
import SwiftUI
import VisionKit
import AVFoundation
import UIKit

struct StudyPairingCode: Decodable {
    let url: String
    let token: String
    static func decode(_ value: String) throws -> Self {
        guard value.utf8.count < 4096, let data = value.data(using: .utf8),
              let code = try? JSONDecoder().decode(Self.self, from: data) else {
            throw StudyError.message("这不是 Loki 的配对二维码。")
        }
        try validate(url: code.url, token: code.token)
        return code
    }
    static func validate(url: String, token: String) throws {
        guard let parts = URLComponents(string: url), parts.scheme == "https",
              let host = parts.host, !host.isEmpty, parts.user == nil, parts.password == nil,
              parts.query == nil, parts.fragment == nil, parts.path.isEmpty || parts.path == "/",
              (32...256).contains(token.count), token.unicodeScalars.allSatisfy({
                  CharacterSet.alphanumerics.contains($0) || "-_".unicodeScalars.contains($0)
              }) else { throw StudyError.message("配对地址或令牌无效，请重新扫描电脑上的配对码。") }
    }
    func probe() async throws {
        try Self.validate(url: url, token: token)
        let base = url.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard let address = URL(string: base + "/v1/status") else { throw StudyError.message("配对地址无效。") }
        var request = URLRequest(url: address, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12)
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        let (data, response) = try await StudyNetwork.session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200,
              let status = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              status["ready"] as? Bool == true else {
            throw StudyError.message("没有取得 Loki 的有效连接回执。原连接设置已保留，请重新生成配对码后再试。")
        }
    }
}

struct StudyPairingScanner: UIViewControllerRepresentable {
    let found: (String) -> Void
    let failed: (String) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(found: found, failed: failed) }
    func makeUIViewController(context: Context) -> DataScannerViewController {
        let controller = DataScannerViewController(recognizedDataTypes: [.barcode(symbologies: [.qr])],
            qualityLevel: .balanced, recognizesMultipleItems: false, isHighFrameRateTrackingEnabled: false,
            isPinchToZoomEnabled: true, isGuidanceEnabled: true, isHighlightingEnabled: true)
        controller.delegate = context.coordinator
        do { try controller.startScanning() }
        catch { DispatchQueue.main.async { failed("相机暂不可用，请检查相机权限后重试。") } }
        return controller
    }
    func updateUIViewController(_ controller: DataScannerViewController, context: Context) {}
    static func dismantleUIViewController(_ controller: DataScannerViewController, coordinator: Coordinator) { controller.stopScanning() }
    final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        let found: (String) -> Void
        let failed: (String) -> Void
        private var finished = false
        init(found: @escaping (String) -> Void, failed: @escaping (String) -> Void) { self.found = found; self.failed = failed }
        func dataScanner(_ scanner: DataScannerViewController, didAdd addedItems: [RecognizedItem], allItems: [RecognizedItem]) {
            guard !finished else { return }
            for item in addedItems {
                if case .barcode(let code) = item, let text = code.payloadStringValue {
                    finished = true; scanner.stopScanning(); found(text); return
                }
            }
        }
        func dataScanner(_ scanner: DataScannerViewController, becameUnavailableWithError error: DataScannerViewController.ScanningUnavailable) {
            guard !finished else { return }; finished = true; failed("扫描中断，请重新打开相机。")
        }
    }
}

struct StudyPairingScanView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var checked = false
    @State private var allowed = false
    let found: (String) -> Void
    let failed: (String) -> Void
    var body: some View {
        NavigationStack {
            Group {
                if !checked { ProgressView("正在准备相机…") }
                else if allowed && DataScannerViewController.isSupported && DataScannerViewController.isAvailable {
                    StudyPairingScanner(found: { value in dismiss(); found(value) }, failed: { value in dismiss(); failed(value) })
                } else {
                    ContentUnavailableView {
                        Label("相机扫描暂不可用", systemImage: "camera")
                    } description: {
                        Text("请允许 Loki 雅思使用相机扫描配对码；也可以返回手动填写连接。")
                    } actions: {
                        Button("打开相机设置") { if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) } }
                    }
                }
            }.navigationTitle("扫描电脑上的 Loki 配对码").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } } }
                .task {
                    let state = AVCaptureDevice.authorizationStatus(for: .video)
                    if state == .authorized { allowed = true }
                    else if state == .notDetermined { allowed = await AVCaptureDevice.requestAccess(for: .video) }
                    else { allowed = false }
                    checked = true
                }
        }
    }
}
