import DeviceActivity
import Foundation

final class StudyMonitor: DeviceActivityMonitor {
    override func intervalDidStart(for activity: DeviceActivityName) {
        super.intervalDidStart(for: activity)
        if activity == StudyFocus.dailyActivity { StudyFocus.refresh() }
    }
    override func intervalDidEnd(for activity: DeviceActivityName) {
        super.intervalDidEnd(for: activity)
        if activity == StudyFocus.examActivity { StudyFocus.endExam() }
        if activity == StudyFocus.dailyActivity { StudyFocus.daily.clearAllSettings() }
    }
}
