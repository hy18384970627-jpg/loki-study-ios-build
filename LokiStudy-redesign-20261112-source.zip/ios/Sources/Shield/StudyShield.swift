import ManagedSettings
import ManagedSettingsUI
import UIKit

final class StudyShield: ShieldConfigurationDataSource {
    private var style: ShieldConfiguration {
        ShieldConfiguration(backgroundBlurStyle: .systemUltraThinMaterialDark,
            backgroundColor: UIColor(red: 0.04, green: 0.12, blue: 0.09, alpha: 1),
            icon: UIImage(systemName: "book.closed.fill"),
            title: .init(text: "Loki · 回来学习", color: .white),
            subtitle: .init(text: StudyFocus.shieldMessage, color: .lightGray),
            primaryButtonLabel: .init(text: "回去背词", color: .black),
            primaryButtonBackgroundColor: UIColor(red: 0.81, green: 0.72, blue: 0.51, alpha: 1))
    }
    override func configuration(shielding application: Application) -> ShieldConfiguration { style }
    override func configuration(shielding application: Application, in category: ActivityCategory) -> ShieldConfiguration { style }
    override func configuration(shielding webDomain: WebDomain) -> ShieldConfiguration { style }
    override func configuration(shielding webDomain: WebDomain, in category: ActivityCategory) -> ShieldConfiguration { style }
}
