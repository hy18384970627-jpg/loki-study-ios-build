import SwiftUI
import WebKit
import FamilyControls
import DeviceActivity
import UserNotifications
import AVFoundation

@main struct LokiStudyApp: App {
    @StateObject private var bridge = StudyBridge()
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            StudyWebView(bridge: bridge)
                .background(Color(red: 0.047, green: 0.082, blue: 0.071))
                .preferredColorScheme(.dark)
                .sheet(item: $bridge.sheet) { item in
                    if item == .connection { StudyConnectionView() } else { StudyFocusView() }
                }
                .onChange(of: phase) { _, new in if new == .active { StudyFocus.refresh() } }
                .task {
                    try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
                    if let time = UserDefaults.standard.string(forKey: "studyReminder") {
                        _ = try? await bridge.invoke("reminder", ["time": time])
                    }
                }
        }
    }
}

enum StudySheet: String, Identifiable { case connection, focus; var id: String { rawValue } }

@MainActor final class StudyBridge: NSObject, ObservableObject, WKScriptMessageHandler, WKNavigationDelegate, WKDownloadDelegate {
    @Published var sheet: StudySheet?
    weak var web: WKWebView?
    private var speaking = false
    private var exportFile: URL?
    private var webRoot: URL? { Bundle.main.url(forResource: "web", withExtension: nil) }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "study", message.frameInfo.isMainFrame,
              let url = message.frameInfo.request.url, isLocal(url),
              let body = message.body as? [String: Any], let id = body["id"] as? String, UUID(uuidString: id) != nil,
              let method = body["method"] as? String else { return }
        Task {
            do { reply(id, ["ok": true, "result": try await invoke(method, body["params"] as? [String: Any] ?? [:])]) }
            catch { reply(id, ["ok": false, "error": error.localizedDescription]) }
        }
    }
    func isLocal(_ url: URL) -> Bool {
        guard url.isFileURL, let root = webRoot else { return false }
        return url.standardizedFileURL.path.hasPrefix(root.standardizedFileURL.path + "/")
    }
    func reply(_ id: String, _ value: [String: Any]) {
        let safeValue: [String: Any] = JSONSerialization.isValidJSONObject(value) ? value : ["ok": false, "error": "响应数据格式无效，原记录已保留。"]
        guard let json = try? JSONSerialization.data(withJSONObject: ["id": id, "value": safeValue]),
              let encoded = String(data: json, encoding: .utf8) else { return }
        web?.evaluateJavaScript("{const r=\(encoded);window.StudyNative?.receive(r.id,r.value);}", completionHandler: nil)
    }
    func summarize(_ events: [[String: Any]]) {
        let day = StudyFocus.day()
        let rows = events.filter { $0["kind"] as? String == "plan" && $0["day"] as? String == day }
        guard let baseRow = rows.last(where: { ($0["payload"] as? [String: Any])?["supplement"] as? Bool != true }),
              let base = baseRow["payload"] as? [String: Any] else { return }
        let plans = rows.filter { ($0["at"] as? String ?? "") >= (baseRow["at"] as? String ?? "") }.compactMap { $0["payload"] as? [String: Any] }
        let extra = plans.filter { $0["supplement"] as? Bool == true }.flatMap { $0["new"] as? [String] ?? [] }
        let words = Set((base["review"] as? [String] ?? []) + (base["new"] as? [String] ?? []) + extra)
        var flags: [String: Bool] = [:]
        for e in events where e["kind"] as? String == "settings" {
            for (id, value) in (e["payload"] as? [String: Any])?["wordFlags"] as? [String: Bool] ?? [:] { flags[id] = value }
        }
        var latest: [String: Bool] = [:]
        for e in events where e["kind"] as? String == "review" && e["day"] as? String == day {
            if e["purpose"] as? String == "practice" { continue }
            if let word = e["word"] as? String, words.contains(word), let rating = e["rating"] as? Int, (1...4).contains(rating) {
                let card = e["cardAfter"] as? [String: Any]
                latest[word] = rating >= 3 && (card == nil || card?["state"] as? Int == 2)
            }
        }
        let remaining = words.filter { flags[$0] != true && latest[$0] != true }.count
        StudyFocus.saveSummary(["day": day, "total": words.count, "remaining": remaining, "complete": !words.isEmpty && remaining == 0])
        if !words.isEmpty && remaining == 0 {
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["LokiStudy-reminder-" + day])
        }
    }
    func invoke(_ method: String, _ params: [String: Any]) async throws -> [String: Any] {
        switch method {
        case "load":
            let events = try StudyStorage.events(); summarize(events)
            return ["events": events, "deviceId": StudyStorage.deviceID,
                    "status": StudyToken.read().isEmpty ? "离线词库已就绪。连接原 Loki 后可使用声音和学习同步。" : "已保存私人连接。实际声音和同步可用性以请求结果为准。"]
        case "save":
            guard let events = params["events"] as? [[String: Any]] else { throw StudyError.message("缺少学习记录。") }
            let saved = try StudyStorage.save(events); summarize(saved); return ["events": saved]
        case "speak":
            guard let text = params["text"] as? String, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, text.count <= 2000 else { throw StudyError.message("单次朗读须为 1—2000 字符，请分段。") }
            let file = try StudyStorage.cacheFile(text)
            if let cached = try? Data(contentsOf: file), cached.prefix(4) == Data("RIFF".utf8) {
                return ["audio": "data:audio/wav;base64," + cached.base64EncodedString(), "cached": true]
            }
            guard !speaking else { throw StudyError.message("正在准备上一段声音。") }
            speaking = true; defer { speaking = false }
            let pcm = try await StudyNetwork.request("/v1/speech/stream", body: ["text": text, "wait_for_slot": false])
            let data = try StudyNetwork.wave(pcm)
            try? StudyStorage.cache(data, text: text)
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
            return ["audio": "data:audio/wav;base64," + data.base64EncodedString(), "cached": false]
        case "sync":
            guard let events = params["events"] as? [[String: Any]] else { throw StudyError.message("缺少同步记录。") }
            let local = try StudyStorage.save(events)
            let data = try await StudyNetwork.request("/v1/study/sync", body: ["events": local, "deviceId": StudyStorage.deviceID])
            guard let result = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let remote = result["events"] as? [[String: Any]] else { throw StudyError.message("同步返回格式异常，本机数据已保留。") }
            let merged = try StudyStorage.save(remote); summarize(merged)
            return ["events": merged, "status": "学习记录已同步"]
        case "configureConnection": sheet = .connection; return ["presented": true]
        case "configureFocus": sheet = .focus; return ["presented": true]
        case "focus":
            if params["active"] as? Bool == false {
                StudyFocus.endExam(); DeviceActivityCenter().stopMonitoring([StudyFocus.examActivity]); return ["active": false]
            }
            guard AuthorizationCenter.shared.authorizationStatus == .approved,
                  StudyFocus.defaults?.bool(forKey: "examAllowed") == true else { throw StudyError.message("请在专注设置中授权，并开启做题时限制应用。") }
            let selection = StudyFocus.selection("examSelection")
            guard StudyFocus.hasSelection(selection) else { throw StudyError.message("请先选择做题时需要限制的应用。") }
            let minutes = params["minutes"] as? Int ?? 60
            guard (15...180).contains(minutes) else { throw StudyError.message("专注时间须为 15—180 分钟。") }
            let end = Date().addingTimeInterval(Double(minutes * 60))
            let c = Calendar.current, parts: Set<Calendar.Component> = [.year, .month, .day, .hour, .minute, .second]
            let schedule = DeviceActivitySchedule(intervalStart: c.dateComponents(parts, from: Date()), intervalEnd: c.dateComponents(parts, from: end), repeats: false)
            try DeviceActivityCenter().startMonitoring(StudyFocus.examActivity, during: schedule)
            StudyFocus.defaults?.set(end, forKey: "examExpires"); StudyFocus.shield(StudyFocus.exam, selection)
            return ["active": true, "expires": end.timeIntervalSince1970]
        case "reminder":
            guard let time = params["time"] as? String else { throw StudyError.message("缺少提醒时间。") }
            let parts = time.split(separator: ":").compactMap { Int($0) }
            guard parts.count == 2, (0...23).contains(parts[0]), (0...59).contains(parts[1]) else { throw StudyError.message("提醒时间格式错误。") }
            let center = UNUserNotificationCenter.current()
            guard try await center.requestAuthorization(options: [.alert, .sound]) else { throw StudyError.message("系统通知未授权，学习计划已保存。") }
            let old = await center.pendingNotificationRequests().filter { $0.identifier.hasPrefix("LokiStudy-reminder-") }.map(\.identifier)
            center.removePendingNotificationRequests(withIdentifiers: old)
            let cal = StudyFocus.calendar
            for offset in 0..<14 {
                guard let day = cal.date(byAdding: .day, value: offset, to: Date()),
                      let date = cal.date(bySettingHour: parts[0], minute: parts[1], second: 0, of: day), date > Date() else { continue }
                let key = StudyFocus.day(date)
                if StudyFocus.defaults?.string(forKey: "completedDay") == key { continue }
                let content = UNMutableNotificationContent()
                content.title = "Loki · 该背词了"
                content.body = "先完成今天的单词。打开 Loki 雅思，我等你回来。"
                content.sound = .default
                let components = cal.dateComponents([.timeZone, .year, .month, .day, .hour, .minute], from: date)
                let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
                try await center.add(.init(identifier: "LokiStudy-reminder-" + key, content: content, trigger: trigger))
            }
            UserDefaults.standard.set(time, forKey: "studyReminder")
            return ["scheduled": true, "days": 14]
        default: throw StudyError.message("此版本暂不支持这项原生操作。")
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if navigationAction.shouldPerformDownload && url.scheme == "blob" { decisionHandler(.download); return }
        decisionHandler(isLocal(url) || url.absoluteString == "about:blank" ? .allow : .cancel)
    }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "-LokiStudy.json")
        exportFile = file; completionHandler(file)
    }
    func downloadDidFinish(_ download: WKDownload) {
        guard let file = exportFile, let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              var controller = scene.windows.first(where: \.isKeyWindow)?.rootViewController else { return }
        while let next = controller.presentedViewController { controller = next }
        let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
        share.popoverPresentationController?.sourceView = controller.view
        controller.present(share, animated: true)
    }
}

struct StudyWebView: UIViewRepresentable {
    @ObservedObject var bridge: StudyBridge
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.userContentController.add(bridge, name: "study")
        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsInlineMediaPlayback = true
        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = bridge; bridge.web = web
        web.isOpaque = false; web.backgroundColor = UIColor(red: 0.047, green: 0.082, blue: 0.071, alpha: 1)
        if let folder = Bundle.main.url(forResource: "web", withExtension: nil) {
            web.loadFileURL(folder.appendingPathComponent("index.html"), allowingReadAccessTo: folder)
        }
        return web
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct StudyConnectionView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var endpoint = UserDefaults.standard.string(forKey: "studyEndpoint") ?? ""
    @State private var token = StudyToken.read()
    @State private var message = ""
    @State private var scanner = false
    @State private var busy = false
    var body: some View {
        NavigationStack {
            Form {
                Section("连接现有 Loki") {
                    Button("扫描电脑上的配对二维码", systemImage: "qrcode.viewfinder") { scanner = true }.disabled(busy)
                    TextField("https:// 私人入口", text: $endpoint).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    SecureField("配对令牌", text: $token).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Text("使用原 Loki 的私人连接设置。令牌只保存在此设备钥匙串，不会写入学习记录。")
                    Button(busy ? "正在验证连接…" : "验证并保存连接") { Task { await connect(StudyPairingCode(url: endpoint.trimmingCharacters(in: .whitespacesAndNewlines), token: token)) } }.disabled(busy)
                }
                Section { Text("本客户端不会启动第二套声音模型。首次朗读从现有服务取得，之后优先使用本机缓存。学习同步需要原网关启用学习接口。") }
                if !message.isEmpty { Text(message).foregroundStyle(.red) }
            }.navigationTitle("Loki 连接").toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
                .sheet(isPresented: $scanner) {
                    StudyPairingScanView(found: { value in
                        do { let code = try StudyPairingCode.decode(value); Task { await connect(code) } }
                        catch { message = error.localizedDescription }
                    }, failed: { message = $0 })
                }
        }
    }
    @MainActor private func connect(_ code: StudyPairingCode) async {
        guard !busy else { return }; busy = true; message = "正在核对 Loki 连接…"
        defer { busy = false }
        do {
            try await code.probe()
            try StudyToken.save(code.token)
            UserDefaults.standard.set(code.url, forKey: "studyEndpoint")
            dismiss()
        } catch { message = "连接未保存：" + error.localizedDescription }
    }
}

struct StudyFocusView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var social = StudyFocus.selection("socialSelection")
    @State private var exam = StudyFocus.selection("examSelection")
    @State private var dailyEnabled = StudyFocus.defaults?.bool(forKey: "dailyEnabled") ?? false
    @State private var examAllowed = StudyFocus.defaults?.bool(forKey: "examAllowed") ?? false
    @State private var socialPicker = false
    @State private var examPicker = false
    @State private var message = ""
    var body: some View {
        NavigationStack {
            Form {
                Section("选择限制范围") {
                    Button("授权屏幕使用时间") { Task { do { try await AuthorizationCenter.shared.requestAuthorization(for: .individual); message = "授权已完成，请选择应用。" } catch { message = error.localizedDescription } } }
                    Button("选择娱乐、社交应用") { socialPicker = true }
                    Text("已选 \(social.applicationTokens.count) 个应用、\(social.categoryTokens.count) 个类别、\(social.webDomainTokens.count) 个网站")
                    Toggle("未完成今日单词时限制社媒", isOn: $dailyEnabled)
                    Button("选择做题时限制的应用") { examPicker = true }
                    Text("已选 \(exam.applicationTokens.count) 个应用、\(exam.categoryTokens.count) 个类别、\(exam.webDomainTokens.count) 个网站")
                    Toggle("做题时允许应用限制", isOn: $examAllowed)
                    Text("请保留 Loki 雅思、电话及必要工具。此设置只影响你选定的范围，不能屏蔽所有系统功能。")
                    Button("保存专注设置") { save() }
                }
                Section("应急") {
                    Button("立即解除本次限制", role: .destructive) {
                        StudyFocus.emergencyRelease(); message = "已解除本次做题限制，今天的背词屏蔽暂停至明天。其他软件设置的限制不受影响。"
                    }
                    Text("可随时关闭上述开关或撤销系统授权。学习进度与应急解除分别记录。")
                }
                if !message.isEmpty { Text(message) }
            }.navigationTitle("学习专注").toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
                .familyActivityPicker(isPresented: $socialPicker, selection: $social)
                .familyActivityPicker(isPresented: $examPicker, selection: $exam)
        }
    }
    func save() {
        do {
            guard let state = StudyFocus.defaults else { throw StudyError.message("此构建尚未完成 App Group 签名。") }
            if dailyEnabled || examAllowed {
                guard AuthorizationCenter.shared.authorizationStatus == .approved else { throw StudyError.message("请先授权屏幕使用时间。") }
            }
            if dailyEnabled && !StudyFocus.hasSelection(social) { throw StudyError.message("请先选择娱乐、社交应用。") }
            if examAllowed && !StudyFocus.hasSelection(exam) { throw StudyError.message("请先选择做题限制范围。") }
            if dailyEnabled {
                let zone = TimeZone(identifier: "Asia/Shanghai")!
                try DeviceActivityCenter().startMonitoring(StudyFocus.dailyActivity,
                    during: DeviceActivitySchedule(intervalStart: DateComponents(timeZone: zone, hour: 0, minute: 0),
                                                   intervalEnd: DateComponents(timeZone: zone, hour: 23, minute: 59), repeats: true))
            } else { DeviceActivityCenter().stopMonitoring([StudyFocus.dailyActivity]); StudyFocus.daily.clearAllSettings() }
            StudyFocus.setSelection(social, key: "socialSelection"); StudyFocus.setSelection(exam, key: "examSelection")
            state.set(dailyEnabled, forKey: "dailyEnabled"); state.set(examAllowed, forKey: "examAllowed")
            if !examAllowed { StudyFocus.endExam(); DeviceActivityCenter().stopMonitoring([StudyFocus.examActivity]) }
            StudyFocus.refresh(); message = "设置已保存。完成今日任务后只解除本软件的背词限制。"
        } catch { message = error.localizedDescription }
    }
}
