import Foundation

let stamp = "2026-11-12T10:00:00.000Z"
let base: [String: Any] = ["id": UUID().uuidString, "at": stamp, "day": "2026-11-12", "kind": "review", "word": "fixture", "rating": 3]
var unsafe = base
unsafe["revlog"] = ["due": Date(), "review": Date()]
var rejected = false
do { _ = try StudyStorage.save([unsafe]) } catch { rejected = true }
precondition(rejected, "Native Date must be rejected before JSON serialization or writing")
var finite = base
finite["durationMs"] = Double.nan
rejected = false
do { try StudyStorage.validate([finite]) } catch { rejected = true }
precondition(rejected, "Non-finite numbers must not reach the native JSON writer")
var safe = base
safe["revlog"] = ["due": stamp, "review": stamp]
safe["cardAfter"] = ["state": 1, "due": stamp]
try StudyStorage.validate([safe])
precondition(JSONSerialization.isValidJSONObject([safe]))
print("Native review boundary: Date and NaN rejected safely; canonical JSON accepted.")
