(()=>{'use strict';
const $=s=>document.querySelector(s),C=StudyCore,baseWords=LOKI_WORDS;
let words=baseWords,byId=Object.fromEntries(words.map(w=>[w.id,w]));
let personalWords=new Set();
const prepared=window.LOKI_STUDY_AUDIO;
const preparedWords=new Set(prepared.words);
const recordedTests=prepared.listening||[];
const builtInTests=[...recordedTests,...LOKI_TESTS];
let events=[],deviceId='browser',plan,queue=[],current,revealed=false,busy=false,mode='ambient',exam=false,tests=builtInTests,part=0,selected=0,audioURL,wordAudio=new Audio(),ranges=[],lastTime=null,checkpoint=0;
let preparation=null;
let activeClip=null,lookupWord=null;
let revealStep=0;
let selectedExample=null,exampleOptions=[];
const lastExamples=new Map();
let syncTimer, syncing=false, syncRetryAt=0;
let wordStartedAt=Date.now(),practice=null,deckPage=0,chosenDeck=null,optimizerRunning=false;
const pending=new Map();
window.StudyNative={receive(id,result){const p=pending.get(id);if(p){pending.delete(id);clearTimeout(p.timer);result.ok?p.resolve(result.result):p.reject(Error(result.error||'操作失败'));}}};
async function native(method,params={}){
 params=C.jsonReady(params);
 if(window.pywebview?.api){const r=await window.pywebview.api.call(method,params);if(!r.ok)throw Error(r.error||'操作失败');return r.result;}
 if(window.webkit?.messageHandlers?.study){return await new Promise((resolve,reject)=>{const id=crypto.randomUUID();const timer=setTimeout(()=>{pending.delete(id);reject(Error('操作超时，请稍后重试'));},240000);pending.set(id,{resolve,reject,timer});window.webkit.messageHandlers.study.postMessage({id,method,params});});}
 if(method==='load')return {events:JSON.parse(localStorage.getItem('loki-study-events')||'[]'),deviceId:'browser'};
 if(method==='save'){localStorage.setItem('loki-study-events',JSON.stringify(params.events));return {};}
 throw Error('请在 Loki 雅思客户端中使用此功能。');
}
function toast(s){$('#toast').textContent=s;$('#toast').hidden=false;setTimeout(()=>$('#toast').hidden=true,6000);}
function event(kind,payload={}){return C.jsonReady({id:crypto.randomUUID(),device:deviceId,at:new Date().toISOString(),day:C.dayKey(),kind,...payload});}
function indexVocabulary(){
 const index=new Map(baseWords.map(word=>[word.id,word]));
 personalWords=new Set();
 for(const entry of events){
   const item=entry.kind==='plan'&&entry.payload?.personalWord;
   if(!item||typeof item.word!=='string'||typeof item.meaning!=='string')continue;
   const id=normalizeHeadword(item.word);
   if(!/^[a-z][a-z '\-]{0,79}$/.test(id)||item.meaning.length>300||!item.meaning.trim())continue;
   const existing=index.get(id);
   index.set(id,{...(existing||{id,word:item.word,phonetic:'',definition:'',rank:999999}),
     meaning:item.meaning,studyPriority:-1,tags:[...new Set([...(existing?.tags||[]),'我的生词'])]});
   personalWords.add(id);
 }
 words=[...index.values()];
 byId=Object.fromEntries(index);
}
function normalizeHeadword(value){return value.trim().toLowerCase().replaceAll('’',"'").replace(/\s+/g,' ');}
async function persist(next){const p=C.todayPlan(words,next),s=C.progress(p,next);const r=await native('save',{events:next,summary:{day:p.day,...s,remaining:s.remaining.length}});events=C.merge(events,C.merge(next,r?.events||[]));indexVocabulary();$('#save-status').textContent='已保存到本机 · '+new Date().toLocaleTimeString('zh-CN');scheduleSync();}
function scheduleSync(){
 if(!window.webkit?.messageHandlers?.study)return;
 clearTimeout(syncTimer);
 syncTimer=setTimeout(()=>syncProgress(),2000);
}
async function syncProgress(manual=false){
 const windows=!!window.pywebview?.api;
 const phone=!!window.webkit?.messageHandlers?.study;
 if(!window.LokiStudyReady||syncing||(!windows&&!phone)||(!manual&&(busy||exam||document.hidden||Date.now()<syncRetryAt)))return;
 syncing=true;
 try{
   if(manual)await saveListen();
   const result=await (windows?native('load'):native('sync',{events}));
   if(!Array.isArray(result.events))throw Error('同步返回格式异常');
   const merged=C.merge(events,result.events);
   if(merged.length!==events.length){
     events=merged;indexVocabulary();
     await ensurePlan();
     const previous=current;
     refresh();
     if(!exam&&queue[0]!==previous)showWord();
     else $('#queue-count').textContent='剩余 '+queue.length+' 词';
   }
   syncRetryAt=0;
   if(phone)$('#save-status').textContent='学习进度已同步 · '+new Date().toLocaleTimeString('zh-CN');
   if(manual)toast(windows?'已读取电脑上的最新进度':'学习进度已同步');
 }catch(error){
   syncRetryAt=Date.now()+15000;
   if(manual)toast('本机记录保留；'+error.message);
 }
 finally{syncing=false;}
}
async function append(e){await persist(C.merge(events,[e]));}
async function ensurePlan(){
 const day=C.dayKey();
 if(!events.some(e=>e.kind==='plan'&&e.day===day&&!e.payload?.supplement))await append(event('plan',{payload:C.newPlan(words,events)}));
 plan=C.todayPlan(words,events);
 // Explicit plan changes create a revision; simply opening the app never adds words.
}
function page(id){
 if($('#gloss').open)$('#gloss').close();
 stopVocabulary();
 document.querySelectorAll('.page').forEach(e=>e.hidden=e.id!==id);
 document.querySelectorAll('nav button').forEach(e=>e.classList.toggle('active',e.dataset.page===(id==='lookup'?'plan':id)));
 document.body.classList.toggle('studying',id==='words');
 window.scrollTo(0,0);
 if(id==='words')showWord();
 if(id==='stats')renderStats();
 if(id==='plan'){renderDecks();renderDeckList();}
}
function refresh(){
 plan=C.todayPlan(words,events);const p=C.progress(plan,events),s=C.settings(events);
 $('#plan-summary').textContent=`今日安排 ${p.total} 词：新学 ${plan.new.length}，复习 ${plan.review.length}。已完成 ${p.done}；稍后再练 ${p.waiting.length}。${plan.backlog?'还有 '+plan.backlog+' 个复习词未排入今日。':''}${plan.warning||''}`;
 for(const[k,v]of Object.entries(s)){const f=$(`#plan-form [name="${k}"]`);if(f&&document.activeElement!==f)f.value=v;}
 queue=(practice?practice.ids.slice(practice.index):p.ready).filter(id=>byId[id]);
 $('#book-caption').textContent=(bookName(s.deck))+' · '+p.done+' / '+p.total;
 document.querySelectorAll('[data-load]').forEach(el=>el.hidden=el.dataset.load!==s.loadMode);
 renderDecks();renderStats();
}
function bookName(id){return (window.LOKI_DECKS||[]).find(d=>d.id===id)?.name||'我的词书';}
function showWord(){
 current=queue[0]; revealed=false; revealStep=0;
 wordStartedAt=Date.now();
 exampleOptions=ExampleBank.choices(prepared,current);
 selectedExample=ExampleBank.choose(exampleOptions,lastExamples.get(current));
 if(selectedExample)lastExamples.set(current,selectedExample.id);
 const choice=$('#example-choice');
 choice.replaceChildren(...exampleOptions.map((row,index)=>new Option((index+1)+' · '+row.type+(row.recording?'':' · 录音待补齐'),row.id)));
 if(selectedExample)choice.value=selectedExample.id;
 $('#example-choice-label').hidden=exampleOptions.length<2;
 if($('#gloss').open)$('#gloss').close();
 const visible=!$('#words').hidden;
 if(visible){stopVocabulary();window.scrollTo(0,0);}
 $('#answer').hidden=true; $('#reveal').hidden=!current; $('#voice-status').textContent='';
 $('#reveal').setAttribute('aria-label',selectedExample?'听例句':'查看释义');
 $('#meaning').hidden=true; $('#example-text').hidden=true; $('#example-translation').hidden=true;
 $('#speak-word').hidden=!current;
 $('#rating-dock').hidden=!current;
 $('#continue-words').hidden=!!current||!plan||!C.additionalWords(words,events,plan,1).length;
 $('#practice-banner').hidden=!practice;
 $('#review-today').hidden=!!current||!!practice||!events.some(e=>e.kind==='review'&&e.day===C.dayKey());
 enableRatings(false);
 const w=byId[current], example=w?selectedExample?.en:'';
 $('#word-example').hidden=!example; $('#example-text').replaceChildren();
 $('#example-translation').textContent=selectedExample?.zh||'';
 const progress=C.progress(plan,events);
 $('#queue-count').textContent=practice?'额外回顾 · 剩余 '+queue.length+' 词':`待学 ${progress.ready.length} · 稍后再练 ${progress.waiting.length} · 已完成 ${progress.done}/${progress.total}`;
 $('#waiting-status').textContent='';
 if(!w){
   $('#word').textContent=practice?'回顾完成':progress.waiting.length?'稍后继续':progress.complete?'今日完成':'今天暂无任务';$('#phonetic').textContent='';
   if(!practice&&progress.nextDue)$('#waiting-status').textContent='下一次练习 '+progress.nextDue.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'})+'，可以先休息或回顾。尚未计为完成。';
   return;
 }
 $('#word').textContent=w.word; $('#phonetic').textContent=w.phonetic?'/'+w.phonetic+'/':'';
 $('#meaning').textContent=w.meaning;
 if(visible)playVocabulary(w,$('#voice-status'));
}
async function continueWords(){
 if(busy||current||!plan)return;
 busy=true;
 const button=$('#continue-words');
 button.disabled=true;
 try{
   await ensurePlan();
   const next=C.additionalWords(words,events,plan);
   if(next.length)await append(event('plan',{payload:{day:plan.day,review:[],new:next,supplement:true}}));
   refresh();
   showWord();
 }catch(error){toast('未能添加新词：'+error.message);}
 finally{busy=false;button.disabled=false;}
}
function enableRatings(enabled){
 document.querySelectorAll('[data-rating]').forEach(button=>button.disabled=!enabled);
}
function revealWord(event){
 if(!current||revealStep>=2||busy)return;
 const example=selectedExample?.en;
 revealStep++;
 $('#answer').hidden=false;
 if(revealStep===1){
   revealed=true;
   if(example){
     renderExampleTokens(example);$('#example-text').hidden=false;
     if(activeClip?.word.id===current&&!activeClip.example)activeClip.playExample=true;
     else playVocabulary(byId[current],$('#voice-status'),true);
   }else $('#voice-status').textContent='该词暂缺例句，再点空白处查看释义。';
   enableRatings(true);
   return;
 }
 $('#meaning').hidden=false;
 $('#example-translation').hidden=!example;
 $('#reveal').hidden=true;
}
function renderExampleTokens(sentence){
 const parts=sentence.split(/([A-Za-z]+(?:[’'\-][A-Za-z]+)*)/g);
 $('#example-text').replaceChildren(...parts.map((part,index)=>{
   if(index%2===0)return document.createTextNode(part);
   const desktop=!!window.pywebview?.api;
   const button=document.createElement(desktop?'span':'button');
   if(desktop){
     button.setAttribute('role','button');button.tabIndex=0;
     button.onkeydown=event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();showGloss(part);}};
   }else button.type='button';
   button.className='sentence-token';button.textContent=part;
   button.onclick=()=>showGloss(part);
   return button;
 }));
}
function showGloss(token){
 const id=token.toLowerCase().replaceAll('’',"'");
 const entry=Object.hasOwn(prepared.glossary||{},id)?prepared.glossary[id]:byId[id];
 $('#gloss-word').textContent=token;
 $('#gloss-meaning').textContent=entry?.meaning||'本地词库暂未收录这个词。';
 $('#gloss-status').textContent='';
 if(!$('#gloss').open)$('#gloss').showModal();
 playVocabulary({id,word:entry?.word||token},$('#gloss-status'),false,entry?.recording,true);
}
function stopVocabulary(){
 if(activeClip)activeClip.status.textContent='';
 activeClip=null;
 wordAudio.onended=null;
 wordAudio.pause();
}
function finishVocabulary(clip){
 if(activeClip!==clip)return;
 activeClip=null;
 if(clip.playExample&&current===clip.word.id&&!$('#words').hidden&&revealStep>0){
   playVocabulary(clip.word,clip.status,true);
 }
}
async function playVocabulary(w,status,example=false,recording,offlineOnly=false){
 if(!w)return;
 stopVocabulary();
 const clip={word:w,status,example,playExample:false};
 activeClip=clip;
 status.textContent='';
 try{
   const variant=example&&w.id===current&&!$('#words').hidden?selectedExample:null;
   const packaged=recording||(variant?variant.recording:(example?prepared.exampleRecordings?.[w.id]:prepared.wordRecordings?.[w.id]));
   if(packaged){
     wordAudio.src=packaged;
   }else if(!variant&&(example?!prepared.exampleRecordings:!prepared.wordRecordings)&&preparedWords.has(w.id)){
     wordAudio.src=`study-audio/${example?'examples':'words'}/${encodeURIComponent(w.id)}.wav`;
   }else{
     if(offlineOnly||example){
       status.textContent=example?'该例句的离线录音尚未就绪':'该词的离线录音尚未收录';
       finishVocabulary(clip);
       return;
     }
     status.textContent='正在准备发音…';
     const result=await native('speak',{text:example?prepared.examples[w.id]:w.word});
     if(activeClip!==clip)return;
     wordAudio.src=result.audio;
   }
   wordAudio.onended=()=>finishVocabulary(clip);
   await wordAudio.play();
   if(activeClip===clip)status.textContent='';
 }catch(error){
   if(activeClip!==clip)return;
   status.textContent=error.name==='NotAllowedError'?'点听筒播放':error.message;
   finishVocabulary(clip);
 }
}
async function rate(r){
 if(busy||!current||!revealed)return;
 busy=true;
 enableRatings(false);
 try{
   const id=current;
   if(practice){practice.index++;await append(event('review',{word:id,rating:r,purpose:'practice',durationMs:Date.now()-wordStartedAt}));}
   else if(r===4)await append(event('settings',{payload:{wordFlags:{[id]:true}}}));
   else await append(event('review',C.reviewResult(events,id,r,new Date(),Date.now()-wordStartedAt)));
   refresh();
   showWord();
 }catch(e){toast('保存失败，未计完成：'+e.message);}
 finally{busy=false;enableRatings(!!current&&revealed);}
}
function showLookup(word){
 stopVocabulary();
 lookupWord=word;
 $('#lookup-result').hidden=!word;
 if(!word)return;
 const example=prepared.examples[word.id]||'';
 $('#lookup-word').textContent=word.word;
 $('#lookup-phonetic').textContent=word.phonetic?'/'+word.phonetic+'/':'';
 $('#lookup-meaning').textContent=word.meaning;
 $('#lookup-definition').textContent=word.definition;
 $('#lookup-tags').textContent=(word.tags||[]).join(' · ');
 $('#save-personal-word').disabled=personalWords.has(word.id);
 $('#save-personal-word').textContent=personalWords.has(word.id)?'已收入生词本':'收入生词本';
 $('#lookup-status').textContent='';
 $('#lookup-example').hidden=!example;
 $('#lookup-example-text').textContent=example;
 $('#lookup-translation').textContent=prepared.exampleTranslations?.[word.id]||'';
}
const t=()=>tests[selected],pt=()=>t().parts[part];
const recordingKey=()=>t().id+'-'+part+'-'+pt().script;
function renderTest(){const select=$('#test-select');select.replaceChildren(...tests.map((x,i)=>new Option(x.title,i)));select.value=selected;$('#test-description').textContent=t().description||t().source||'';$('#part-select').replaceChildren(...t().parts.map((x,i)=>new Option(x.title||'Part '+(i+1),i)));$('#part-select').value=part;renderPart();loadPartAudio();}
function renderPart(){lastTime=null;ranges=[];$('#questions').replaceChildren();for(const q of pt().questions){const d=document.createElement('div');d.className='question';const l=document.createElement('label');l.textContent=q.id+'. '+q.prompt;const input=document.createElement('input');input.dataset.q=q.id;input.autocomplete='off';input.value=JSON.parse(sessionStorage.getItem('answers-'+t().id)||'{}')[q.id]||'';input.oninput=()=>{const a=JSON.parse(sessionStorage.getItem('answers-'+t().id)||'{}');a[q.id]=input.value;sessionStorage.setItem('answers-'+t().id,JSON.stringify(a));};l.append(input);d.append(l);$('#questions').append(d);}$('#questions').hidden=mode!=='exam';$('#submit-test').hidden=mode!=='exam';$('#transcript').hidden=mode==='exam';$('#transcript p').textContent=pt().script;$('#audio').loop=mode==='ambient'&&$('#repeat-audio').checked;$('#audio').controls=!exam;$('#coverage').textContent='播放覆盖按实际播放区间记录；拖动进度不算听完。';}
function validateTest(x){if(!x||typeof x.id!=='string'||typeof x.title!=='string'||!Array.isArray(x.parts)||x.parts.length!==4)throw Error('需要四部分的听力题包');let ids=new Set();for(const p of x.parts){if(typeof p.script!=='string'||!Array.isArray(p.questions)||p.questions.length!==10)throw Error('每部分需要原文与10题');for(const q of p.questions){if(ids.has(String(q.id))||typeof q.prompt!=='string'||!Array.isArray(q.answers)||!q.answers.length||q.answers.some(a=>typeof a!=='string'))throw Error('题号或答案格式有误');ids.add(String(q.id));}}return x;}
function norm(x){return x.toLowerCase().trim().replace(/[.,!?]/g,'').replace(/\s+/g,' ');}
async function saveListen(){if(!ranges.length||!Number.isFinite($('#audio').duration))return;await append(event('listen',{payload:{test:t().id,part:pt().id||String(part),mode,ranges:[...ranges],duration:$('#audio').duration}}));}
function setAudio(url){const audio=$('#audio');audio.pause();if(audioURL?.startsWith('blob:'))URL.revokeObjectURL(audioURL);audioURL=url;if(url)audio.src=url;else{audio.removeAttribute('src');audio.load();}lastTime=null;ranges=[];}
function stopPreparation(){
 preparation=null;
 $('#generate-audio').textContent='准备录音';
}
async function loadPartAudio(){
 stopPreparation();
 const key=recordingKey();
 setAudio('');
 if(recordedTests.includes(t())&&pt().recording){
   setAudio(pt().recording);
   $('#generate-audio').hidden=true;
   $('#audio-status').textContent='录音已就绪，可直接播放。';
   return;
 }
 $('#generate-audio').hidden=false;
 $('#audio-status').textContent='请选择录音或准备当前部分的录音。';
 const cached=await audioCache(key).catch(()=>null);
 if(cached&&!audioURL&&recordingKey()===key){
   setAudio(URL.createObjectURL(cached));
   $('#generate-audio').hidden=true;
   $('#audio-status').textContent='已载入本地录音。';
 }
}
function audioCache(key,value){
 return new Promise((resolve,reject)=>{
   const request=indexedDB.open('LokiStudyAudio',1);
   const timer=setTimeout(()=>reject(Error('本地录音缓存暂不可用')),5000);
   const fail=error=>{clearTimeout(timer);reject(error||Error('本地录音缓存不可用'));};
   request.onupgradeneeded=()=>request.result.createObjectStore('audio');
   request.onerror=()=>fail(request.error);
   request.onblocked=()=>fail();
   request.onsuccess=()=>{
     const db=request.result;
     try{
       const tx=db.transaction('audio',value?'readwrite':'readonly'),store=tx.objectStore('audio');
       const operation=value?store.put(value,key):store.get(key);
       tx.oncomplete=()=>{db.close();clearTimeout(timer);resolve(operation.result);};
       tx.onabort=()=>{db.close();fail(tx.error);};
     }catch(error){db.close();fail(error);}
   };
 });
}
function chunks(text){
 const limit=420,result=[];
 let current='';
 const add=value=>{
   if(current&&current.length+value.length+1>limit){result.push(current);current='';}
   current=current?current+' '+value:value;
 };
 for(const sentence of text.trim().split(/(?<=[.!?])\s+|\n+/)){
   const value=sentence.trim();
   if(!value)continue;
   if(value.length<=limit)add(value);
   else for(const word of value.split(/\s+/)){
     if(word.length>limit)throw Error('原文含无法朗读的超长词项');
     add(word);
   }
 }
 if(current)result.push(current);
 return result;
}
function joinWaves(arrays){
 const pcm=[];
 let format;
 for(const bytes of arrays){
   const tag=off=>String.fromCharCode(...bytes.subarray(off,off+4));
   if(bytes.length<44||tag(0)!=='RIFF'||tag(8)!=='WAVE')throw Error('录音格式错误');
   const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
   let data=null,fmt=null;
   for(let off=12;off+8<=bytes.length;){
     const size=v.getUint32(off+4,true),end=off+8+size;
     if(end>bytes.length)throw Error('录音数据不完整');
     if(tag(off)==='fmt '&&size>=16)fmt=bytes.subarray(off+8,off+24);
     if(tag(off)==='data')data=bytes.subarray(off+8,end);
     off=end+(size%2);
   }
   if(!fmt||!data?.length||data.length%2)throw Error('录音数据不完整');
   if(format&&!format.every((byte,i)=>byte===fmt[i]))throw Error('各段录音格式不一致');
   format=fmt;pcm.push(data);
 }
 if(!format)throw Error('当前部分没有可朗读的原文');
 const total=pcm.reduce((n,p)=>n+p.length,0),header=new Uint8Array(44),view=new DataView(header.buffer);
 header.set(new TextEncoder().encode('RIFF'),0);header.set(new TextEncoder().encode('WAVEfmt '),8);
 view.setUint32(4,total+36,true);view.setUint32(16,16,true);header.set(format,20);
 header.set(new TextEncoder().encode('data'),36);view.setUint32(40,total,true);
 return new Blob([header,...pcm],{type:'audio/wav'});
}
async function generateAudio(){
 if(exam)return;
 if(preparation){stopPreparation();$('#audio-status').textContent='已停止。已保存的小段会在下次继续时使用。';return;}
 const key=recordingKey(),run={};
 preparation=run;
 $('#generate-audio').textContent='停止准备';
 try{
   const texts=chunks(pt().script);
   let blob=await audioCache(key).catch(()=>null);
   if(!blob){
     const clips=[];
     for(const [index,text] of texts.entries()){
       if(preparation!==run)return;
       $('#audio-status').textContent=`已完成 ${index}/${texts.length}，正在准备第 ${index+1} 小段。`;
       const chunkKey='listen-v2:'+key+':'+index;
       let clip=await audioCache(chunkKey).catch(()=>null);
       if(!clip){
         if(preparation!==run)return;
         let timer;
         try{
           const response=await Promise.race([native('speak',{text}),new Promise((_,reject)=>{
             timer=setTimeout(()=>reject(Error('当前小段生成超时')),85000);
           })]);
           const bytes=Uint8Array.from(atob(response.audio.split(',')[1]),c=>c.charCodeAt(0));
           clip=joinWaves([bytes]);
           await audioCache(chunkKey,clip).catch(()=>{});
         }finally{clearTimeout(timer);}
       }
       clips.push(new Uint8Array(await clip.arrayBuffer()));
     }
     if(preparation!==run)return;
     blob=joinWaves(clips);
     try{await audioCache(key,blob);}catch(error){toast('录音可播放，但离线缓存未保存。');}
   }
   if(preparation===run){setAudio(URL.createObjectURL(blob));$('#audio-status').textContent='录音已就绪。';$('#generate-audio').hidden=true;}
 }catch(error){if(preparation===run)$('#audio-status').textContent=error.message+'。已保存的小段可继续使用。';}
 finally{if(preparation===run)stopPreparation();}
}
function element(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function renderDecks(){
 const s=C.settings(events),active=chosenDeck||s.deck,tabs=$('#deck-tabs');tabs.replaceChildren();
 for(const d of window.LOKI_DECKS||[]){const b=element('button',d.name.replace(' · 基础词库',''));b.classList.toggle('selected',d.id===active);b.setAttribute('aria-pressed',String(d.id===active));b.onclick=()=>{chosenDeck=d.id;deckPage=0;renderDecks();renderDeckList();};tabs.append(b);}
 const d=(window.LOKI_DECKS||[]).find(x=>x.id===active),book=C.deckWords(words,{...s,deck:active}),{cards}=C.materialize(events);
 $('#deck-summary').replaceChildren(element('h2',d?.name||'我的词书'),element('p',book.length+' 词 · 已学 '+book.filter(w=>cards[w.id]).length+' · 熟知 '+book.filter(w=>s.wordFlags[w.id]).length),element('p',d?.notice||'', 'hint'));
 if(chosenDeck&&chosenDeck!==s.deck)$('#deck-summary').append(element('p','点击下方“保存并调整今天的任务”后开始使用此词书。','hint'));
}
function renderDeckList(){
 const s=C.settings(events),q=$('#deck-filter').value.trim().toLowerCase(),book=C.deckWords(words,{...s,deck:chosenDeck||s.deck}).filter(w=>!q||w.word.toLowerCase().includes(q)||w.meaning.includes(q)),max=Math.max(0,Math.ceil(book.length/50)-1);
 deckPage=Math.min(deckPage,max);const out=$('#deck-word-list');out.replaceChildren();const {cards}=C.materialize(events);
 for(const w of book.slice(deckPage*50,deckPage*50+50)){
  const row=element('div',undefined,'deck-word'),b=element('button',w.word+' · '+(s.wordFlags[w.id]?'熟知':cards[w.id]?'已学':'未学'),'quiet');b.onclick=()=>{showLookup(w);page('lookup');};
  const known=element('button',s.wordFlags[w.id]?'恢复复习':'熟知','quiet');known.onclick=async()=>{try{await append(event('settings',{payload:{wordFlags:{[w.id]:!s.wordFlags[w.id]}}}));refresh();renderDeckList();}catch(e){toast(e.message);}};
  row.append(b,known);out.append(row);
 }
 $('#deck-page').textContent=' '+(deckPage+1)+' / '+(max+1)+' ';$('#deck-prev').disabled=!deckPage;$('#deck-next').disabled=deckPage>=max;
}
function bars(id,rows,stacked){
 const out=$(id);out.replaceChildren();const max=Math.max(1,...rows.map(r=>stacked?r.new+r.review:r.count));
 for(const r of rows){const column=element('div',undefined,'chart-column'),value=stacked?r.new+r.review:r.count;
  column.append(element('span',String(value),'chart-value'));
  const plot=element('div',undefined,'chart-track');
  if(stacked){const a=element('div',undefined,'bar-new'),b=element('div',undefined,'bar-review');a.style.height=(r.new/max*120)+'px';b.style.height=(r.review/max*120)+'px';plot.append(b,a);}else{const bar=element('div',undefined,'bar-review');bar.style.height=(value/max*120)+'px';plot.append(bar);}
  column.title=r.day+'：'+(stacked?'新学 '+r.new+'，复习 '+r.review:'到期 '+r.count);column.setAttribute('aria-label',column.title);column.append(plot,element('span',r.day.slice(5)));out.append(column);
 }
}
function renderStats(){
 const s=C.settings(events),p=C.progress(plan||C.todayPlan(words,events),events),data=C.stats(words,events),box=$('#stats-summary');box.replaceChildren();
 for(const [label,value]of [['今日完成',p.done+'/'+p.total],['累计已学',data.globalLearned],['本书未学',data.unseen],['稍后再练',p.waiting.length]]){const card=element('div',undefined,'metric');card.append(element('strong',String(value)),element('span',label));box.append(card);}
 $('#book-progress-label').textContent=bookName(s.deck)+' · 有学习记录 '+data.learned+' / '+data.total+' · 熟知 '+data.known;
 $('#book-progress').value=data.total?(data.total-data.unseen)/data.total*100:0;
 const calendar=$('#study-calendar');calendar.replaceChildren();for(const d of data.history){const n=d.new+d.review,b=element('button',d.day.slice(-2),'heat-day');b.dataset.level=n===0?'0':n<20?'1':n<60?'2':'3';b.title=d.day+'：新学 '+d.new+'，复习 '+d.review+'，作答 '+d.attempts+' 次';b.setAttribute('aria-label',b.title);b.onclick=()=>toast(b.title+(d.minutes?'；有效作答时间 '+d.minutes+' 分钟':''));calendar.append(b);}
 bars('#history-chart',data.history.slice(-7),true);bars('#forecast-chart',data.forecast,false);
 const personal=s.personalization;
 $('#personal-status').textContent=personal?'已使用个人参数 · '+personal.reviews+' 次跨日记录；验证损失 '+personal.metrics.baselineLogLoss.toFixed(3)+' → '+personal.metrics.candidateLogLoss.toFixed(3):'使用 FSRS-6 默认参数。记录足够后可在电脑端训练；无改善时保持原参数。';
 $('#reset-personal').disabled=!personal;
}
function startPractice(ids){practice={ids:[...new Set(ids)].filter(id=>byId[id]),index:0};refresh();page('words');}
const reviewCard=$('.review-card');
// The complete study screen is a tap target, but controls keep their own action.
// Ignore a click following text selection or a scroll/drag gesture.
let pagePointer=null;
document.addEventListener('pointerdown',e=>{pagePointer={x:e.clientX,y:e.clientY};},{passive:true});
document.addEventListener('click',e=>{
 if($('#words').hidden||document.querySelector('dialog[open]')||window.getSelection()?.toString().trim())return;
 if(e.target.closest('button,input,select,textarea,label,a,summary,details,audio,video,dialog,[contenteditable="true"],[role="button"],[role="link"],[role="slider"],[role="dialog"],.sentence-token,[data-no-reveal]'))return;
 if(pagePointer&&Math.hypot(e.clientX-pagePointer.x,e.clientY-pagePointer.y)>12)return;
 revealWord(e);
});
reviewCard.addEventListener('keydown',e=>{if(e.target===reviewCard&&(e.key==='Enter'||e.key===' ')){e.preventDefault();revealWord(e);}});
$('#end-practice').onclick=()=>{practice=null;refresh();showWord();};
$('#review-today').onclick=()=>startPractice(events.filter(e=>e.kind==='review'&&e.day===C.dayKey()).map(e=>e.word));
$('#review-known').onclick=()=>{const ids=Object.entries(C.settings(events).wordFlags).filter(([,v])=>v).map(([id])=>id);if(!ids.length)return toast('还没有标记熟知的单词。');chosenDeck=C.settings(events).deck;page('plan');$('#deck-filter').value='';renderDeckList();toast('在词书列表中点击“恢复复习”，可以撤销熟知。');};
$('#deck-filter').oninput=()=>{deckPage=0;renderDeckList();};$('#deck-prev').onclick=()=>{deckPage--;renderDeckList();};$('#deck-next').onclick=()=>{deckPage++;renderDeckList();};
$('#plan-form [name="loadMode"]').onchange=e=>document.querySelectorAll('[data-load]').forEach(el=>el.hidden=el.dataset.load!==e.target.value);
$('#optimize').onclick=async()=>{
 if(optimizerRunning)return;if(!window.pywebview?.api)return toast('请在 Windows 版的“进度”页训练个人参数，手机通过现有同步接收。');
 optimizerRunning=true;$('#optimize').disabled=true;$('#personal-status').textContent='正在本机训练，并用后段记录验证…';
 try{const r=await native('optimize');if(r.accepted){if(!C.validWeights(r.weights))throw Error('参数格式无效，未启用');await append(event('settings',{payload:{personalization:{...r,trainedAt:new Date().toISOString()}}}));refresh();}else renderStats();toast(r.reason);}catch(e){renderStats();toast('原参数保留：'+e.message);}finally{optimizerRunning=false;$('#optimize').disabled=false;}
};
$('#reset-personal').onclick=async()=>{try{await append(event('settings',{payload:{personalization:null}}));refresh();toast('已恢复默认参数，保留原有到期日期。');}catch(e){toast(e.message);}};
document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>page(b.dataset.page));document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>page(b.dataset.go));$('#start').onclick=()=>page('words');$('#reveal').onclick=revealWord;document.querySelectorAll('[data-rating]').forEach(b=>b.onclick=()=>rate(+b.dataset.rating));
$('#gloss-close').onclick=()=>$('#gloss').close();
$('#gloss').onclick=e=>{if(e.target===$('#gloss'))$('#gloss').close();};
$('#continue-words').onclick=continueWords;
$('#speak-word').onclick=()=>playVocabulary(byId[current],$('#voice-status'));
$('#speak-example').onclick=()=>playVocabulary(byId[current],$('#voice-status'),true);
$('#example-choice').onchange=event=>{
 const example=exampleOptions.find(row=>row.id===event.target.value);
 if(!example)return;
 selectedExample=example;lastExamples.set(current,example.id);
 $('#example-translation').textContent=example.zh;
 if(revealStep>=2)renderExampleTokens(example.en);
 playVocabulary(byId[current],$('#voice-status'),true);
};
$('#lookup-speak').onclick=()=>playVocabulary(lookupWord,$('#lookup-status'));
$('#lookup-speak-example').onclick=()=>playVocabulary(lookupWord,$('#lookup-status'),true);
function renderWordSearch(){
 const q=normalizeHeadword($('#word-search').value),scope=$('#word-scope').value,out=$('#search-results');
 showLookup(null);
 out.replaceChildren();
 if(!q&&!scope)return;
 const matches=words.filter(w=>(!scope||w.tags?.includes(scope))&&(!q||w.id.includes(q)||w.meaning.includes(q))).sort((a,b)=>
   (a.id===q?0:a.id.startsWith(q)?1:2)-(b.id===q?0:b.id.startsWith(q)?1:2));
 if(!matches.length){out.textContent='未找到匹配词条';return;}
 for(const w of matches.slice(0,30)){
   const button=document.createElement('button');
   button.textContent=w.word;
   button.onclick=()=>showLookup(w);
   out.append(button);
 }
}
async function savePersonalWord(word,meaning){
 const id=normalizeHeadword(word);
 if(!/^[a-z][a-z '\-]{0,79}$/.test(id)||!meaning.trim()||meaning.length>300)throw Error('请输入英文词或短语及中文释义。');
 if(personalWords.has(id))return;
 await append(event('plan',{payload:{day:C.dayKey(),review:[],new:[],supplement:true,personalWord:{word:word.trim(),meaning:meaning.trim()}}}));
 refresh();
 toast('已收入生词本，后续新词会优先安排。');
 showLookup(byId[id]);
}
$('#word-search').oninput=renderWordSearch;
$('#word-scope').onchange=renderWordSearch;
for(const tag of [...new Set([...baseWords.flatMap(w=>w.tags||[]),'我的生词'])])$('#word-scope').add(new Option(tag,tag));
$('#save-personal-word').onclick=async()=>{const w=lookupWord;if(w)try{await savePersonalWord(w.word,w.topicMeaning||w.meaning.slice(0,300));}catch(e){toast(e.message);}};
$('#personal-word-form').onsubmit=async e=>{e.preventDefault();try{const data=new FormData(e.target);await savePersonalWord(data.get('word'),data.get('meaning'));e.target.reset();}catch(error){toast(error.message);}};
$('#plan-form').onsubmit=async e=>{e.preventDefault();try{
 const s=Object.fromEntries(new FormData(e.target));for(const k of ['minutes','vocabMinutes','newLimit','dailyLimit','reviewLimit','retention'])s[k]=+s[k];
 if(s.vocabMinutes>s.minutes)throw Error('背词时间不能超过每天总时间');
 if(!Number.isInteger(s.dailyLimit)||s.dailyLimit<1||s.dailyLimit>1000||!Number.isInteger(s.newLimit)||s.newLimit<0||s.newLimit>500||!Number.isInteger(s.reviewLimit)||s.reviewLimit<0||s.reviewLimit>2000)throw Error('请填写有效的学习量。');
 s.deck=chosenDeck||C.settings(events).deck;practice=null;
 // Persist settings and the replacement plan atomically; retain all original events.
 const change=event('settings',{payload:s}),next=C.merge(events,[change]);
 const revision=event('plan',{payload:C.newPlan(words,next)});revision.at=new Date(Math.max(Date.now(),Date.parse(change.at)+1)).toISOString();
 await persist(C.merge(next,[revision]));chosenDeck=null;refresh();renderDeckList();
 const receipt=s.reminder?await native('reminder',{time:s.reminder}).catch(()=>null):null;
 toast(receipt?.status||(receipt?'计划与提醒已保存。':'学习计划已保存。'));
}catch(e){toast(e.message);}};
$('#sync').onclick=()=>syncProgress(true);
$('#connection').onclick=async()=>{try{const r=await native('configureConnection');$('#connection-status').textContent=r?.status||'已打开连接设置，请在设置中完成保存。';}catch(e){toast(e.message);}};$('#focus-settings').onclick=async()=>{try{const r=await native('configureFocus');if(r?.status)toast(r.status);}catch(e){toast(e.message);}};
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{if(exam)return toast('先结束本次做题专注');mode=b.dataset.mode;document.querySelectorAll('[data-mode]').forEach(x=>x.classList.toggle('selected',x===b));renderPart();});
$('#test-select').onchange=async e=>{if(exam){e.target.value=selected;return;}await saveListen();selected=+e.target.value;part=0;renderTest();};$('#part-select').onchange=async e=>{if(exam){e.target.value=part;return;}await saveListen();part=+e.target.value;renderPart();loadPartAudio();};$('#repeat-audio').onchange=e=>$('#audio').loop=mode==='ambient'&&e.target.checked;
$('#import-test').onclick=()=>$('#test-file').click();$('#test-file').onchange=async e=>{try{const x=validateTest(JSON.parse(await e.target.files[0].text()));if(recordedTests.some(test=>test.id===x.id))throw Error('题包编号与内置录音重复');tests=[...tests.filter(t=>t.id!==x.id),x];localStorage.setItem('loki-imported-tests',JSON.stringify(tests.filter(t=>!builtInTests.some(y=>y.id===t.id))));selected=tests.length-1;part=0;renderTest();toast('题包已导入');}catch(e){toast(e.message);}};
$('#import-audio').onclick=()=>$('#audio-file').click();$('#audio-file').onchange=async e=>{const f=e.target.files[0];if(f){stopPreparation();setAudio(URL.createObjectURL(f));$('#audio-status').textContent='已选择：'+f.name;}};$('#generate-audio').onclick=generateAudio;
$('#audio').ontimeupdate=()=>{const a=$('#audio'),now=a.currentTime;if(!a.paused&&lastTime!==null&&now>=lastTime&&now-lastTime<=2)ranges.push([lastTime,now]);lastTime=now;$('#coverage').textContent=`本次本段实际播放覆盖 ${Math.round(C.coverage(ranges,a.duration)*100)}%`;if(Date.now()-checkpoint>30000&&ranges.length){checkpoint=Date.now();saveListen().catch(e=>toast(e.message));}};$('#audio').onseeking=()=>{lastTime=null;};$('#audio').onpause=()=>{lastTime=null;saveListen().catch(()=>{});};$('#audio').onended=()=>saveListen().catch(e=>toast(e.message));
$('#exam-start').onclick=async()=>{if(mode!=='exam')return toast('请先选择听力模拟测试');if(!audioURL)return toast('请先准备当前部分的录音');try{await native('focus',{active:true,minutes:60});exam=true;$('#exam-stop').hidden=false;$('#audio').controls=false;$('#audio').loop=false;$('#transcript').hidden=true;await $('#audio').play();toast('模拟测试已开始');}catch(e){toast(e.message);}};$('#exam-stop').onclick=async()=>{try{await native('focus',{active:false});exam=false;$('#exam-stop').hidden=true;$('#audio').controls=true;}catch(e){toast(e.message);}};
$('#submit-test').onclick=async()=>{try{const a=JSON.parse(sessionStorage.getItem('answers-'+t().id)||'{}'),qs=t().parts.flatMap(p=>p.questions),score=qs.filter(q=>q.answers.some(x=>norm(x)===norm(a[q.id]||''))).length;await append(event('test',{payload:{test:t().id,score,total:qs.length,answers:a}}));await native('focus',{active:false});exam=false;$('#exam-stop').hidden=true;$('#audio').controls=true;$('#test-result').textContent=`本套 ${score}/${qs.length}。这是训练正确数，不自动换算雅思分数。`;$('#transcript').hidden=false;for(const el of document.querySelectorAll('[data-q]')){const q=qs.find(q=>String(q.id)===el.dataset.q),d=document.createElement('p');d.className='feedback';d.textContent='答案：'+q.answers.join(' / ')+'。'+(q.explanation||'');el.parentNode.append(d);}}catch(e){toast(e.message);}};
function download(name,data){const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),3000);}
$('#export').onclick=()=>download('LokiStudy-'+C.dayKey()+'.json',{version:1,events});$('#import-state').onclick=()=>$('#state-file').click();$('#state-file').onchange=async e=>{try{const x=JSON.parse(await e.target.files[0].text());if(x.version!==1||!Array.isArray(x.events))throw Error('无效备份');await persist(C.merge(events,x.events));await ensurePlan();refresh();toast('备份已合并，已有记录保留。');}catch(e){toast(e.message);}};
async function init(){try{if(!window.webkit?.messageHandlers?.study&&!window.pywebview?.api)await new Promise(r=>{window.addEventListener('pywebviewready',r,{once:true});setTimeout(r,1000);});const s=await native('load');events=C.merge([],s.events||[]);indexVocabulary();deviceId=s.deviceId||crypto.randomUUID();if(!C.settings(events).migration){await append(event('settings',{payload:{migration:{version:2,legacyRetention:C.settings(events).retention}}}));}const imported=JSON.parse(localStorage.getItem('loki-imported-tests')||'[]');tests=[...builtInTests,...imported.map(validateTest).filter(test=>!recordedTests.some(ready=>ready.id===test.id))];await ensurePlan();refresh();showWord();selected=Math.floor(Date.now()/86400000)%(recordedTests.length||tests.length);renderTest();$('#date').textContent=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',dateStyle:'full'}).format(new Date());$('#sources').textContent=`${baseWords.length} 个备考词条，含 ECDICT、NGSL、NAWL 和主题词。${preparedWords.size} 个词已有离线录音。`;$('#connection-status').textContent=window.pywebview?.api?'学习进度保存在电脑。应用打开时会自动读取手机同步过来的记录。':(s.status||'连接现有 Loki 后可自动同步学习进度。');window.LokiStudyReady=true;}catch(e){$('#save-status').textContent='加载失败：'+e.message;toast(e.message);}}
setInterval(async()=>{if(plan&&plan.day!==C.dayKey()&&!busy){try{await ensurePlan();refresh();showWord();toast('已更新今天的学习任务。');}catch(e){toast(e.message);}}},30000);
init().then(()=>{page('words');syncProgress();});
setInterval(()=>{if(!window.LokiStudyReady||busy||practice||!plan)return;const p=C.progress(plan,events);if(!current&&p.ready.length){refresh();showWord();}else if(!current&&!$('#words').hidden)showWord();},5000);
setInterval(()=>syncProgress(),20000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)syncProgress();});
window.addEventListener('focus',()=>syncProgress());
})();
